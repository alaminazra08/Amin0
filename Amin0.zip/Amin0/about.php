 <?php
session_start();
include __DIR__ . "/includes/config.php";

/* =========================
   AMBIL DATA ABOUT
========================= */
$about = mysqli_query($conn, "SELECT * FROM about LIMIT 1");
$dataAbout = mysqli_fetch_assoc($about);
$team = mysqli_query($conn, "SELECT * FROM team");
$kategori = $_GET['kategori'] ?? '';

// ambil kategori untuk navbar
$kategoriNav = mysqli_query($conn, "
    SELECT DISTINCT kategori
    FROM berita
    WHERE kategori IS NOT NULL
    AND kategori != ''
    ORDER BY kategori ASC
");
if (!$dataAbout) {
    $dataAbout = [
        'id' => 0,
        'hero_judul' => 'Tentang Kami',
        'hero_deskripsi' => 'Deskripsi website',
        'judul' => '',
        'deskripsi' => '',
        'foto' => '',
        'judul2' => '',
        'deskripsi2' => '',
        'foto2' => ''
    ];
}
/* =========================
   PROSES TEAM
========================= */

if (isset($_POST['tambah_team']) && isset($_SESSION['role']) && $_SESSION['role'] == 'admin') {
    $nama = $_POST['nama'];
    $jabatan = $_POST['jabatan'];
    $foto = '';

    if (isset($_FILES['foto_team']) && $_FILES['foto_team']['name'] != '') {
        $namaFile = time() . '_' . $_FILES['foto_team']['name'];
        move_uploaded_file($_FILES['foto_team']['tmp_name'], "uploads/" . $namaFile);
        $foto = $namaFile;
    }

    mysqli_query($conn, "INSERT INTO team (nama,jabatan,foto) VALUES('$nama','$jabatan','$foto')");

    header("Location: about.php");
    exit;
}

if (isset($_POST['update_team']) && isset($_SESSION['role']) && $_SESSION['role'] == 'admin') {
    $id = $_POST['id'];
    $nama = $_POST['nama'];
    $jabatan = $_POST['jabatan'];

    $dataLama = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM team WHERE id=$id"));
    $foto = $dataLama['foto'];

    if (isset($_FILES['foto_team']) && $_FILES['foto_team']['name'] != '') {
        $namaFile = time() . '_' . $_FILES['foto_team']['name'];
        move_uploaded_file($_FILES['foto_team']['tmp_name'], "uploads/" . $namaFile);
        $foto = $namaFile;
    }

    mysqli_query($conn, "UPDATE team SET
        nama='$nama',
        jabatan='$jabatan',
        foto='$foto'
        WHERE id=$id");

    header("Location: about.php");
    exit;
}

if (isset($_GET['hapus']) && isset($_SESSION['role']) && $_SESSION['role'] == 'admin') {
    $id = $_GET['hapus'];
    mysqli_query($conn, "DELETE FROM team WHERE id=$id");
    header("Location: about.php");
    exit;
}

/* =========================
   PROSES UPDATE ABOUT
========================= */

if (isset($_POST['update_about']) && isset($_SESSION['role']) && $_SESSION['role'] == 'admin') {
    $hero_judul = $_POST['hero_judul'];
    $hero_deskripsi = $_POST['hero_deskripsi'];
    $judul = $_POST['judul'];
    $deskripsi = $_POST['deskripsi'];
    $judul2 = $_POST['judul2'];
    $deskripsi2 = $_POST['deskripsi2'];

    $foto = $dataAbout['foto'];
    $foto2 = $dataAbout['foto2'];

    if (isset($_FILES['foto']) && $_FILES['foto']['name'] != '') {
        $namaFile = time() . '_' . $_FILES['foto']['name'];
        move_uploaded_file($_FILES['foto']['tmp_name'], "uploads/" . $namaFile);
        $foto = $namaFile;
    }

    if (isset($_FILES['foto2']) && $_FILES['foto2']['name'] != '') {
        $namaFile2 = time() . '_' . $_FILES['foto2']['name'];
        move_uploaded_file($_FILES['foto2']['tmp_name'], "uploads/" . $namaFile2);
        $foto2 = $namaFile2;
    }

    if ($dataAbout['id'] == 0) {
        mysqli_query($conn, "INSERT INTO about
        (hero_judul,hero_deskripsi,judul,deskripsi,foto,judul2,deskripsi2,foto2)
        VALUES('$hero_judul','$hero_deskripsi','$judul','$deskripsi','$foto','$judul2','$deskripsi2','$foto2')");
    } else {
        mysqli_query($conn, "UPDATE about SET
            hero_judul='$hero_judul',
            hero_deskripsi='$hero_deskripsi',
            judul='$judul',
            deskripsi='$deskripsi',
            foto='$foto',
            judul2='$judul2',
            deskripsi2='$deskripsi2',
            foto2='$foto2'
            WHERE id=" . $dataAbout['id']);
    }

    header("Location: about.php");
    exit;
}

/* ====== SEMUA LOGIC PHP TIDAK DIUBAH ====== */
?>
<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>About</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        html {
            overflow-y: scroll;
        }

        body {
            padding-top: 110px;
            background: linear-gradient(to bottom, #f8fafc, #eef2f7);
            font-family: 'Segoe UI', sans-serif;
            overflow-x: hidden;
        }

        .navbar-top {
            background: rgba(255, 255, 255, 0.75);
            backdrop-filter: blur(15px);
            border-bottom: 1px solid rgba(255, 255, 255, 0.3);
            box-shadow: 0 5px 25px rgba(0, 0, 0, 0.08);
            z-index: 1055;
        }

        .navbar-menu {
            background: rgba(255, 255, 255, 0.65);
            backdrop-filter: blur(12px);
            border-bottom: 1px solid rgba(255, 255, 255, 0.3);
            z-index: 1040;
        }

        .navbar-brand,
        .brand-title {
            font-weight: 800;
            font-size: 20px;
            letter-spacing: 1px;
            background: linear-gradient(45deg, #0d6efd, #6610f2);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .brand-subtitle {
            font-size: 11px;
            color: #6b7280;
        }

        .nav-link {
            position: relative;
            font-weight: 500;
            color: #333 !important;
            transition: 0.3s;
        }

        .nav-link::after {
            content: "";
            position: absolute;
            left: 0;
            bottom: -5px;
            width: 0;
            height: 2px;
            background: #0d6efd;
            transition: 0.3s;
        }

        .nav-link:hover,
        .nav-link.active {
            color: #0d6efd !important;
        }

        .nav-link:hover::after,
        .nav-link.active::after {
            width: 100%;
        }

        .search-box {
            max-width: 500px;
            width: 100%;
            position: relative;
        }

        .search-box input {
            padding-left: 40px;
            border-radius: 30px;
            border: none;
            background: #f1f5f9;
            box-shadow: inset 0 2px 5px rgba(0, 0, 0, 0.05);
            transition: 0.3s;
        }

        .search-box input:focus {
            background: #fff;
            box-shadow: 0 0 0 3px rgba(13, 110, 253, 0.2);
        }

        .search-box i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #888;
        }

        .btn-search {
            border-radius: 30px;
            height: 46px;
            background: linear-gradient(45deg, #0d6efd, #6610f2);
            color: white;
            border: none;
            font-weight: 600;
            padding: 0 22px;
            transition: 0.3s;
            white-space: nowrap;
        }

        .btn-search:hover {
            transform: translateY(-1px);
            box-shadow: 0 6px 18px rgba(13, 110, 253, 0.3);
        }

        .avatar {
            width: 38px;
            height: 38px;
            border-radius: 50%;
            border: 2px solid #0d6efd;
            transition: 0.3s;
        }

        .avatar:hover {
            transform: scale(1.1);
            box-shadow: 0 0 10px rgba(13, 110, 253, 0.5);
        }

        .dropdown-menu {
            border-radius: 12px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
            border: none;
        }

        .about-hero {
            padding: 100px 0;
            background: linear-gradient(135deg, #0d6efd, #2563eb, #1d4ed8);
            color: white;
        }

        .team-card {
            border-radius: 16px;
            padding: 1.5rem;
            background: #fff;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.08);
            transition: 0.3s;
        }

        .team-card:hover {
            transform: translateY(-4px);
        }

        .content-card {
            padding: 2rem;
            background: #fff;
            border-radius: 18px;
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.08);
        }

        .about-img {
            border-radius: 18px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.08);
        }

        .user-box {
            cursor: pointer;
            padding: 5px 10px;
            border-radius: 30px;
            transition: 0.3s;
        }

        .user-box:hover {
            background: rgba(0, 0, 0, 0.05);
        }

        @media (max-width: 768px) {
            .search-box {
                max-width: 100%;
            }

            .team-card {
                min-height: 100%;
            }
        }
    </style>
</head>

<body>
    <!-- ================= NAVBAR ================= -->
    <nav class="navbar navbar-top fixed-top py-2">
    <div class="container d-flex align-items-center justify-content-between">

        <!-- BRAND -->
        <a class="navbar-brand d-flex flex-column" href="index.php">
            <span class="brand-title">
                ⚡ Kabar<span class="text-primary">Nusantara</span>
            </span>
            <small class="brand-subtitle">Berita Cepat & Terpercaya</small>
        </a>

        <!-- SEARCH -->
       <form class="search-box d-flex align-items-center position-relative mx-auto"
      method="GET" action="index.php">

    <i class="bi bi-search"></i>

    <input type="text"
           name="keyword"
           class="form-control"
           placeholder="Cari berita viral hari ini..."
           value="<?= htmlspecialchars($keyword ?? '', ENT_QUOTES); ?>">

    <?php if($kategori != ''): ?>
        <input type="hidden" name="kategori" value="<?= htmlspecialchars($kategori) ?>">
    <?php endif; ?>

    <button class="btn btn-search ms-2 px-4" type="submit">
        Cari
    </button>
</form>

        <!-- USER AREA -->
        <div class="d-flex align-items-center gap-3">

            <?php if (isset($_SESSION['user']) && $_SESSION['role'] == 'admin'): ?>
                <a href="admin/dashboard.php" class="btn btn-warning btn-sm fw-semibold shadow-sm">
                    <i class="bi bi-speedometer2"></i> Dashboard
                </a>
            <?php endif; ?>

            <?php if (isset($_SESSION['user'])): ?>
                <div class="dropdown">
                    <a data-bs-toggle="dropdown" class="d-flex align-items-center gap-2 user-box">
                        <img src="https://ui-avatars.com/api/?name=<?= urlencode($_SESSION['user']); ?>&background=0D6EFD&color=fff&bold=true"
                            class="avatar"
                            alt="Avatar">
                        <span class="d-none d-md-block fw-semibold"><?= htmlspecialchars($_SESSION['user']); ?></span>
                        <i class="bi bi-chevron-down small"></i>
                    </a>

                    <ul class="dropdown-menu dropdown-menu-end shadow border-0 mt-2">
                        <li class="dropdown-item fw-semibold"><?= htmlspecialchars($_SESSION['user']); ?></li>
                        <li><hr></li>
                        <li>
                            <a class="dropdown-item text-danger" href="logout.php">
                                <i class="bi bi-box-arrow-right me-1"></i> Logout
                            </a>
                        </li>
                    </ul>
                </div>
            <?php else: ?>
                <a href="login.php" class="btn btn-primary btn-sm px-3 shadow-sm">
                    <i class="bi bi-person"></i> Login
                </a>
            <?php endif; ?>

        </div>
    </div>
</nav>

    <!-- NAVBAR MENU (UPGRADE) -->
<nav class="navbar navbar-menu fixed-top" style="top:65px;">
    <div class="container">
        <div class="d-flex justify-content-center w-100">
            <ul class="navbar-nav flex-row gap-4 flex-wrap align-items-center">

                <!-- HOME -->
                <li class="nav-item">
                    <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'index.php' && $kategori == '' ? 'active' : '' ?>"
                       href="index.php">
                        <i class="bi bi-house-door me-1"></i> Home
                    </a>
                </li>

                <!-- KATEGORI -->
                <?php while($kat = mysqli_fetch_assoc($kategoriNav)): ?>
                    <li class="nav-item">
                        <a class="nav-link <?= $kategori == $kat['kategori'] ? 'active' : '' ?>"
                           href="index.php?kategori=<?= urlencode($kat['kategori']) ?>">
                            <i class="bi bi-grid me-1"></i>
                            <?= htmlspecialchars($kat['kategori']) ?>
                        </a>
                    </li>
                <?php endwhile; ?>

                <!-- ABOUT -->
                <li class="nav-item">
                    <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'about.php' ? 'active' : '' ?>"
                       href="about.php">
                        <i class="bi bi-info-circle me-1"></i> About
                    </a>
                </li>

                <!-- CONTACT -->
                <li class="nav-item">
                    <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'contact.php' ? 'active' : '' ?>"
                       href="contact.php">
                        <i class="bi bi-envelope me-1"></i> Contact
                    </a>
                </li>

            </ul>
        </div>
    </div>
</nav>
    <!-- ===== SISA KODE KAMU (TIDAK DIUBAH) ===== -->

    <header class="about-hero text-center">
        <div class="container">
            <h1 class="fw-bold display-4"><?= !empty($dataAbout['hero_judul']) ? htmlspecialchars($dataAbout['hero_judul']) : 'Tentang Kami'; ?></h1>
            <p class="lead"><?= !empty($dataAbout['hero_deskripsi']) ? htmlspecialchars($dataAbout['hero_deskripsi']) : 'Deskripsi website'; ?></p>
            <a href="#cerita" class="btn btn-light mt-3">Lihat Cerita Kami ↓</a>
        </div>
    </header>

    <!-- LANJUTAN KODE KAMU TETAP -->

    <section class="py-5" id="cerita">
        <div class="container">
            <div class="row align-items-center g-4">
                <div class="col-lg-6">
                    <img src="<?= (!empty($dataAbout['foto']) && file_exists('uploads/' . $dataAbout['foto'])) ? htmlspecialchars('uploads/' . $dataAbout['foto']) : 'assets/images/600x400.png'; ?>" class="img-fluid about-img">
                </div>
                <div class="col-lg-6">
                    <div class="content-card">
                        <h3><?= htmlspecialchars($dataAbout['judul']); ?></h3>
                        <p class="text-muted mb-0"><?= htmlspecialchars($dataAbout['deskripsi']); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="py-5">
        <div class="container">
            <div class="row align-items-center g-4">
                <div class="col-lg-6 order-lg-2">
                    <img src="<?= (!empty($dataAbout['foto2']) && file_exists('uploads/' . $dataAbout['foto2'])) ? htmlspecialchars('uploads/' . $dataAbout['foto2']) : 'assets/images/600x400.png'; ?>" class="img-fluid about-img">
                </div>
                <div class="col-lg-6 order-lg-1">
                    <div class="content-card">
                        <h3><?= !empty($dataAbout['judul2']) ? htmlspecialchars($dataAbout['judul2']) : 'Pertumbuhan'; ?></h3>
                        <p class="text-muted mb-0"><?= !empty($dataAbout['deskripsi2']) ? htmlspecialchars($dataAbout['deskripsi2']) : 'Kami terus berkembang dengan inovasi terbaru.'; ?></p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="py-5" id="team">
        <div class="container text-center">
            <h3 class="fw-bold mb-2">Meet Our Professional Team</h3>
            <p class="text-muted mb-5">Tim terbaik yang bekerja dengan inovasi dan kolaborasi.</p>
            <div class="row">
                <?php while ($t = mysqli_fetch_assoc($team)) { ?>
                    <div class="col-md-3 mb-4">
                        <div class="team-card">
                            <div id="view-<?= $t['id']; ?>">
                                <img src="<?= htmlspecialchars('uploads/' . $t['foto']); ?>" class="rounded-circle mb-3" width="120" height="120" style="object-fit:cover;">
                                <h6><?= htmlspecialchars($t['nama']); ?></h6>
                                <small class="text-muted"><?= htmlspecialchars($t['jabatan']); ?></small>
                                <?php if (isset($_SESSION['role']) && $_SESSION['role'] == 'admin') { ?>
                                    <div class="mt-3">
                                        <button type="button" onclick="toggleEdit(<?= $t['id']; ?>)" class="btn btn-warning btn-sm">Edit</button>
                                        <a href="about.php?hapus=<?= $t['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin hapus?')">Hapus</a>
                                    </div>
                                <?php } ?>
                            </div>
                            <!-- =======================
                                 BLOK EDIT TEAM MODIFIKASI
                            ======================= -->
                            <div id="edit-<?= $t['id']; ?>" style="display:none;">
                                <div class="card border-0 shadow-sm p-3 mt-3" style="border-radius:18px; background:#f8fafc;">
                                    <h6 class="fw-bold mb-3 text-primary">
                                        <i class="bi bi-pencil-square"></i> Edit Data Team
                                    </h6>
                                    <form method="POST" enctype="multipart/form-data">
                                        <input type="hidden" name="id" value="<?= $t['id']; ?>">
                                        <label class="form-label small fw-semibold">Nama</label>
                                        <input type="text" name="nama" value="<?= htmlspecialchars($t['nama']); ?>" class="form-control mb-3" placeholder="Masukkan nama team">
                                        <label class="form-label small fw-semibold">Jabatan</label>
                                        <input type="text" name="jabatan" value="<?= htmlspecialchars($t['jabatan']); ?>" class="form-control mb-3" placeholder="Masukkan jabatan">
                                        <label class="form-label small fw-semibold">Foto Baru</label>
                                        <input type="file" name="foto_team" class="form-control mb-3">
                                        <div class="d-grid gap-2">
                                            <button name="update_team" class="btn btn-success">
                                                <i class="bi bi-check-circle"></i> Simpan Perubahan
                                            </button>
                                            <button type="button" onclick="toggleEdit(<?= $t['id']; ?>)" class="btn btn-outline-secondary">
                                                <i class="bi bi-x-circle"></i> Batal
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <!-- =======================
                                 END BLOK EDIT TEAM
                            ======================= -->
                        </div>
                    </div>
                <?php } ?>
            </div>
        </div>
    </section>

    <?php if (isset($_SESSION['role']) && $_SESSION['role'] == 'admin'): ?>
        <div class="container mb-5">
            <div class="row g-4">
                <div class="col-lg-7">
                    <div class="card p-4">
                        <h5>Edit About</h5>
                        <form method="POST" enctype="multipart/form-data">
                            <input type="text" name="hero_judul" class="form-control mb-2" value="<?= htmlspecialchars($dataAbout['hero_judul']); ?>">
                            <textarea name="hero_deskripsi" class="form-control mb-3"><?= htmlspecialchars($dataAbout['hero_deskripsi']); ?></textarea>
                            <input type="text" name="judul" class="form-control mb-2" value="<?= htmlspecialchars($dataAbout['judul']); ?>">
                            <textarea name="deskripsi" class="form-control mb-3"><?= htmlspecialchars($dataAbout['deskripsi']); ?></textarea>
                            <input type="file" name="foto" class="form-control mb-3">
                            <input type="text" name="judul2" class="form-control mb-2" value="<?= htmlspecialchars($dataAbout['judul2']); ?>">
                            <textarea name="deskripsi2" class="form-control mb-3"><?= htmlspecialchars($dataAbout['deskripsi2']); ?></textarea>
                            <input type="file" name="foto2" class="form-control mb-3">
                            <button name="update_about" class="btn btn-primary w-100">Update About</button>
                        </form>
                    </div>
                </div>
                <div class="col-lg-5">
                    <div class="card p-4">
                        <h5>Tambah Team</h5>
                        <form method="POST" enctype="multipart/form-data">
                            <input type="text" name="nama" class="form-control mb-2" placeholder="Nama">
                            <input type="text" name="jabatan" class="form-control mb-2" placeholder="Jabatan">
                            <input type="file" name="foto_team" class="form-control mb-3">
                            <button name="tambah_team" class="btn btn-success w-100">Tambah Team</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <footer class="bg-white border-top">
        <div class="container text-center py-4">
            <small>© <?= date('Y'); ?> Kabar Nusantara</small>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function toggleEdit(id) {
            const view = document.getElementById("view-" + id);
            const edit = document.getElementById("edit-" + id);
            if (edit.style.display === "none") {
                view.style.display = "none";
                edit.style.display = "block";
            } else {
                view.style.display = "block";
                edit.style.display = "none";
            }
        }
    </script>
</body>
</html>