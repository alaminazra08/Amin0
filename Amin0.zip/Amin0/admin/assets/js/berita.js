// Berita JS Functions
