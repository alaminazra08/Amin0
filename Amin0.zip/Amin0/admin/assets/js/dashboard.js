// ====== UPDATE JAM DAN TANGGAL REALTIME ======
function updateDateTime() {
    const now = new Date();
    const hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"];
    const bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli",
                   "Agustus", "September", "Oktober", "November", "Desember"];

    const h = hari[now.getDay()];
    const tgl = now.getDate();
    const bln = bulan[now.getMonth()];
    const thn = now.getFullYear();

    const jam = String(now.getHours()).padStart(2, '0');
    const menit = String(now.getMinutes()).padStart(2, '0');
    const detik = String(now.getSeconds()).padStart(2, '0');

    document.getElementById("tanggal").innerText = `${h}, ${tgl} ${bln} ${thn}`;
    document.getElementById("jam").innerText = `${jam}:${menit}:${detik}`;
}

setInterval(updateDateTime, 1000);
updateDateTime();

// ====== CHART STATISTIK BERITA ======
document.addEventListener('DOMContentLoaded', function() {
    const ctx = document.getElementById('chartBerita');
    if (ctx) {
        const gradient = ctx.getContext('2d').createLinearGradient(0, 0, 0, 300);
        gradient.addColorStop(0, "rgba(37, 99, 235, 0.6)");
        gradient.addColorStop(1, "rgba(37, 99, 235, 0)");

        new Chart(ctx, {
            type: 'line',
            data: {
                labels: window.dataBulanChart || [],
                datasets: [{
                    label: 'Jumlah Berita',
                    data: window.dataTotalChart || [],
                    fill: true,
                    backgroundColor: gradient,
                    borderColor: "#2563eb",
                    borderWidth: 3,
                    pointBackgroundColor: "#2563eb",
                    pointBorderColor: "#fff",
                    pointBorderWidth: 2,
                    pointRadius: 5,
                    hoverRadius: 7,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                interaction: {
                    mode: 'index',
                    intersect: false
                },
                plugins: {
                    legend: {
                        display: true,
                        labels: {
                            color: "#334155",
                            font: { size: 13 }
                        }
                    },
                    tooltip: {
                        backgroundColor: "#020617",
                        titleColor: "#fff",
                        bodyColor: "#fff",
                        padding: 10
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            stepSize: 1,
                            callback: function(value) {
                                return Number.isInteger(value) ? value : null;
                            }
                        },
                        grid: {
                            color: "#e5e7eb"
                        }
                    }
                }
            }
        });
    }
});

// ====== COUNTER ANIMATION ======
function initCounters() {
    const counters = document.querySelectorAll('.counter');

    counters.forEach(counter => {
        const updateCount = () => {
            const target = +counter.getAttribute('data-target');
            const count = +counter.innerText;
            const speed = 100;
            const increment = target / speed;

            if (count < target) {
                counter.innerText = Math.ceil(count + increment);
                setTimeout(updateCount, 30);
            } else {
                counter.innerText = target;
            }
        };

        updateCount();
    });
}

document.addEventListener('DOMContentLoaded', initCounters);

// ====== TOGGLE SIDEBAR ======
function toggleSidebar() {
    const sidebar = document.querySelector(".sidebar");
    const main = document.querySelector(".main");

    sidebar.classList.toggle("small");
    main.classList.toggle("full");
}
