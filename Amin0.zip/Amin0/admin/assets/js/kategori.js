// Kategori JS Functions
