// Komentar JS Functions
