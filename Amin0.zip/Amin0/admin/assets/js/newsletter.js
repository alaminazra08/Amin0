// Newsletter JS Functions
