<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

ob_start();
session_start();
require_once __DIR__ . '/../../includes/config.php';

if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../../login.php');
    exit;
}

$id = intval($_GET['id'] ?? 0);
if ($id <= 0) {
    header('Location: kelola.php');
    exit;
}

$beritaResult = mysqli_query($conn, "SELECT * FROM berita WHERE id = $id");
$berita = $beritaResult ? mysqli_fetch_assoc($beritaResult) : null;
if (!$berita) {
    header('Location: kelola.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['simpan'])) {
    $judul = $conn->real_escape_string(trim($_POST['judul'] ?? ''));
    $kategori = $conn->real_escape_string(trim($_POST['kategori'] ?? ''));
    $isi = $conn->real_escape_string(trim($_POST['isi'] ?? ''));
    $penulis = $conn->real_escape_string(trim($_POST['penulis'] ?? ''));
    $gambar = $berita['gambar'];

    if (!empty($_FILES['gambar']['name'])) {
        $gambar = basename($_FILES['gambar']['name']);
        move_uploaded_file($_FILES['gambar']['tmp_name'], __DIR__ . '/../../uploads/' . $gambar);
    }

    $updateQuery = "UPDATE berita SET judul='$judul', kategori='$kategori', isi='$isi', gambar='$gambar', penulis='$penulis' WHERE id = $id";
    mysqli_query($conn, $updateQuery);

    header('Location: kelola.php?success=updated');
    exit;
}

$kategoriList = [];
$kategoriResult = mysqli_query($conn, 'SELECT * FROM kategori ORDER BY nama_kategori ASC');
if ($kategoriResult) {
    while ($row = mysqli_fetch_assoc($kategoriResult)) {
        $kategoriList[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Berita | Admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/dashboard.css">
    <link rel="stylesheet" href="../assets/css/berita.css">
</head>
<body>
<div class="admin-wrapper">
    <div class="sidebar">
        <div class="d-flex align-items-center justify-content-between mb-3">
            <h4 class="mb-0">ADMIN PANEL</h4>
            <button onclick="toggleSidebar()" class="btn btn-sm btn-dark">☰</button>
        </div>
        
        <small class="text-uppercase text-secondary d-block mb-2">Menu Utama</small>
        <a href="../dashboard.php">
            <i class="fa fa-home"></i> <span>Dashboard</span>
        </a>
        <a href="../kategori.php">
            <i class="fa fa-tags me-2"></i> <span>Kategori</span>
        </a>

        <!-- MENU BERITA -->
        <a href="#" role="button" data-bs-toggle="collapse" data-bs-target="#menuBerita">
            <i class="fa fa-newspaper me-2"></i> <span>Berita</span>
            <i class="fa fa-chevron-down float-end"></i>
        </a>
        <div class="collapse show" id="menuBerita">
            <a href="tambah.php" class="ms-4">
                ➕ Tambah Berita
            </a>
            <a href="kelola.php" class="ms-4 active">
                📰 Data Berita
            </a>
        </div>
        
        <hr class="text-secondary">
        <small class="text-uppercase text-secondary d-block mb-2">Data</small>
        <a href="../newsletter.php">
            <i class="fa fa-envelope me-2"></i> <span>Data Newsletter</span>
        </a>
        <a href="../komentar.php">
            <i class="fa fa-comments me-2"> </i><span>Komentar</span>
        </a>
        <a href="../contact.php">
            <i class="fa fa-envelope me-2"> </i><span>Pesan Contact</span>
        </a>
        
        <hr class="text-secondary">
        <small class="text-uppercase text-secondary d-block mb-2">Lainnya</small>
        <a href="../../index.php">
            <i class="fa fa-globe me-2"></i> <span>Lihat Website</span>
        </a>
        <a href="../../logout.php" class="text-danger">
            <i class="fa fa-sign-out-alt me-2"></i><span>Logout</span>
        </a>
    </div>

    <div class="main">
        <!-- HEADER -->
        <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
            <div>
                <h4 class="mb-1 fw-bold">
                    <i class="fa fa-edit text-primary me-2"></i>
                    Edit Berita
                </h4>
                <p class="text-muted mb-0 small">Perbarui informasi dan konten artikel berita</p>
            </div>
            <a href="kelola.php" class="btn btn-outline-secondary btn-sm shadow-sm">
                <i class="fa fa-arrow-left me-1"></i>Kembali ke Kelola Berita
            </a>
        </div>

        <!-- FORM CARD -->
        <div class="card border-0 shadow-sm">
            <div class="card-body p-4">
                <form method="POST" enctype="multipart/form-data" action="">
                    <div class="row g-4">
                        <!-- JUDUL -->
                        <div class="col-12">
                            <label class="form-label fw-semibold">
                                <i class="fa fa-heading text-primary me-1"></i>
                                Judul Berita
                            </label>
                            <input type="text" name="judul" class="form-control form-control-lg" required
                                   value="<?= htmlspecialchars($berita['judul'], ENT_QUOTES) ?>"
                                   placeholder="Masukkan judul berita yang menarik...">
                            <small class="text-muted">Judul akan ditampilkan sebagai headline artikel</small>
                        </div>

                        <!-- PENULIS & KATEGORI -->
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">
                                <i class="fa fa-user text-primary me-1"></i>
                                Nama Penulis
                            </label>
                            <input type="text" name="penulis" class="form-control" required
                                   value="<?= htmlspecialchars($berita['penulis'], ENT_QUOTES) ?>"
                                   placeholder="Nama penulis artikel">
                        </div>

                        <div class="col-md-6">
                            <label class="form-label fw-semibold">
                                <i class="fa fa-tags text-primary me-1"></i>
                                Kategori
                            </label>
                            <select name="kategori" class="form-select" required>
                                <option value="">-- Pilih Kategori --</option>
                                <?php foreach ($kategoriList as $k): ?>
                                    <option value="<?= htmlspecialchars($k['nama_kategori'], ENT_QUOTES) ?>"
                                        <?= $berita['kategori'] === $k['nama_kategori'] ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($k['nama_kategori']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <!-- GAMBAR -->
                        <div class="col-12">
                            <label class="form-label fw-semibold">
                                <i class="fa fa-image text-primary me-1"></i>
                                Gambar Utama
                            </label>
                            <input type="file" name="gambar" class="form-control" accept="image/*">
                            <small class="text-muted">
                                <i class="fa fa-info-circle me-1"></i>
                                Format: JPG, PNG, GIF. Biarkan kosong jika tidak ingin mengubah gambar.
                            </small>
                            <?php if (!empty($berita['gambar'])): ?>
                                <div class="mt-3 p-3 bg-light rounded">
                                    <small class="text-muted d-block mb-2">
                                        <i class="fa fa-image me-1"></i>Gambar saat ini:
                                    </small>
                                    <img src="../../uploads/<?= htmlspecialchars($berita['gambar']) ?>"
                                         width="200" height="120" class="rounded object-cover border" alt="Gambar saat ini">
                                </div>
                            <?php endif; ?>
                        </div>

                        <!-- ISI BERITA -->
                        <div class="col-12">
                            <label class="form-label fw-semibold">
                                <i class="fa fa-file-alt text-primary me-1"></i>
                                Isi Berita
                            </label>
                            <textarea name="isi" class="form-control" rows="12" required
                                      placeholder="Tulis isi berita lengkap di sini..."><?= htmlspecialchars($berita['isi']) ?></textarea>
                            <small class="text-muted">
                                <i class="fa fa-lightbulb me-1"></i>
                                Tip: Pastikan informasi akurat dan artikel bermanfaat bagi pembaca.
                            </small>
                        </div>

                        <!-- BUTTONS -->
                        <div class="col-12">
                            <hr class="my-4">
                            <div class="d-flex gap-2 justify-content-end">
                                <a href="kelola.php" class="btn btn-outline-secondary">
                                    <i class="fa fa-times me-1"></i>Batal
                                </a>
                                <button name="simpan" class="btn btn-primary px-4" type="submit">
                                    <i class="fa fa-save me-1"></i>Simpan Perubahan
                                </button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/dashboard.js"></script>
<script src="../assets/js/berita.js"></script>
</body>
</html>
<?php ob_end_flush(); ?>
