<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

ob_start();
session_start();
require_once __DIR__ . "/../../includes/config.php";

// ===== PROTEKSI AKSES ADMIN =====
if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../../login.php");
    exit;
}

// ===== PROSES HAPUS BERITA =====
if (isset($_GET['hapus'])) {
    $id = intval($_GET['hapus']);
    mysqli_query($conn, "DELETE FROM berita WHERE id=$id");
    header("Location: kelola.php?success=deleted");
    exit;
}

// ===== GET SEMUA BERITA =====
$beritaList = [];
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

if (!empty($search)) {
    // Search query
    $searchTerm = $conn->real_escape_string($search);
    $result = mysqli_query($conn, "SELECT * FROM berita WHERE 
        judul LIKE '%$searchTerm%' OR 
        kategori LIKE '%$searchTerm%' OR 
        penulis LIKE '%$searchTerm%' OR
        isi LIKE '%$searchTerm%'
        ORDER BY id DESC");
} else {
    // Default query
    $result = mysqli_query($conn, "SELECT * FROM berita ORDER BY id DESC");
}

if ($result) {
    while ($b = mysqli_fetch_assoc($result)) {
        $beritaList[] = $b;
    }
}

// ===== TOTAL BERITA =====
$totalBerita = count($beritaList);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Kelola Berita | Admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/dashboard.css">
    <link rel="stylesheet" href="../assets/css/berita.css">
</head>
<body>
<div class="admin-wrapper">
    <div class="sidebar">
        <div class="d-flex align-items-center justify-content-between mb-3">
            <h4 class="mb-0">ADMIN PANEL</h4>
            <button onclick="toggleSidebar()" class="btn btn-sm btn-dark">☰</button>
        </div>
        
        <small class="text-uppercase text-secondary d-block mb-2">Menu Utama</small>
        <a href="../dashboard.php">
            <i class="fa fa-home"></i> <span>Dashboard</span>
        </a>
        <a href="../kategori.php">
            <i class="fa fa-tags me-2"></i> <span>Kategori</span>
        </a>

        <!-- MENU BERITA -->
        <a href="#" role="button" data-bs-toggle="collapse" data-bs-target="#menuBerita">
            <i class="fa fa-newspaper me-2"></i> <span>Berita</span>
            <i class="fa fa-chevron-down float-end"></i>
        </a>
        <div class="collapse show" id="menuBerita">
            <a href="tambah.php" class="ms-4">
                ➕ Tambah Berita
            </a>
            <a href="kelola.php" class="ms-4 active">
                📰 Data Berita
            </a>
        </div>
        
        <hr class="text-secondary">
        <small class="text-uppercase text-secondary d-block mb-2">Data</small>
        <a href="../newsletter.php">
            <i class="fa fa-envelope me-2"></i> <span>Data Newsletter</span>
        </a>
        <a href="../komentar.php">
            <i class="fa fa-comments me-2"></i> <span>Komentar</span>
        </a>
        <a href="../contact.php">
            <i class="fa fa-envelope me-2"></i> <span>Pesan Contact</span>
        </a>
        
        <hr class="text-secondary">
        <small class="text-uppercase text-secondary d-block mb-2">Lainnya</small>
        <a href="../../index.php">
            <i class="fa fa-globe me-2"></i><span>Lihat Website</span>
        </a>
        <a href="../../logout.php" class="text-danger">
            <i class="fa fa-sign-out-alt me-2"></i><span>Logout</span>
        </a>
    </div>

    <div class="main">
        <!-- HEADER -->
        <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
            <div>
                <h4 class="mb-1 fw-bold">
                    <i class="fa fa-list text-primary me-2"></i>
                    Kelola Berita
                </h4>
                <p class="text-muted mb-0 small">Kelola semua artikel berita yang telah dipublikasikan</p>
            </div>
            <div class="d-flex gap-2">
                <span class="badge bg-primary px-3 py-2 shadow-sm">
                    <i class="fa fa-newspaper me-1"></i>
                    Total: <?= intval($totalBerita); ?> Berita
                </span>
                <a href="tambah.php" class="btn btn-primary shadow-sm">
                    <i class="fa fa-plus me-1"></i>Tambah Berita
                </a>
            </div>
        </div>

        <!-- ALERT SUCCESS -->
        <?php if (isset($_GET['success'])): ?>
            <div class="alert alert-success alert-dismissible fade show shadow-sm mb-4" role="alert">
                <i class="fa fa-check-circle me-2"></i>
                <?php
                switch ($_GET['success']) {
                    case 'deleted':
                        echo 'Berita berhasil dihapus!';
                        break;
                    case '1':
                        echo 'Berita berhasil ditambahkan!';
                        break;
                    case 'updated':
                        echo 'Berita berhasil diperbarui!';
                        break;
                    default:
                        echo 'Operasi berhasil!';
                }
                ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <!-- SEARCH FORM -->
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-body p-3">
                <form method="GET" class="row g-3 align-items-end">
                    <div class="col-md-8">
                        <label class="form-label fw-semibold small">
                            <i class="fa fa-search text-primary me-1"></i>Cari Berita
                        </label>
                        <input type="text" name="search" class="form-control"
                               placeholder="Cari berdasarkan judul, penulis, atau kategori..."
                               value="<?= htmlspecialchars($_GET['search'] ?? '') ?>">
                    </div>
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="fa fa-search me-1"></i>Cari
                        </button>
                    </div>
                    <div class="col-md-2">
                        <?php if (isset($_GET['search'])): ?>
                            <a href="kelola.php" class="btn btn-outline-secondary w-100">
                                <i class="fa fa-times me-1"></i>Reset
                            </a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>

        <!-- TABLE CARD -->
        <div class="card border-0 shadow-sm">
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th width="5%" class="text-center">No</th>
                                <th>Judul Berita</th>
                                <th>Kategori</th>
                                <th>Penulis</th>
                                <th>Gambar</th>
                                <th width="15%" class="text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($beritaList)): ?>
                                <?php $no = 1; ?>
                                <?php foreach ($beritaList as $b): ?>
                                    <tr>
                                        <td class="text-center text-muted fw-semibold">
                                            <?= $no++ ?>
                                        </td>
                                        <td>
                                            <div class="fw-semibold text-truncate" style="max-width: 300px;" title="<?= htmlspecialchars($b['judul']) ?>">
                                                <?= htmlspecialchars($b['judul']) ?>
                                            </div>
                                            <small class="text-muted">
                                                <i class="fa fa-calendar me-1"></i>
                                                <?= date('d M Y', strtotime($b['tanggal'])) ?>
                                            </small>
                                        </td>
                                        <td>
                                            <?php
                                            $kategori = strtolower($b['kategori']);
                                            $warna = "bg-secondary";
                                            if (strpos($kategori, 'politik') !== false) $warna = "bg-danger";
                                            elseif (strpos($kategori, 'olahraga') !== false) $warna = "bg-success";
                                            elseif (strpos($kategori, 'teknologi') !== false) $warna = "bg-info";
                                            elseif (strpos($kategori, 'pendidikan') !== false) $warna = "bg-warning text-dark";
                                            elseif (strpos($kategori, 'hiburan') !== false) $warna = "bg-dark";
                                            ?>
                                            <span class="badge <?= $warna ?> px-2 py-1">
                                                <i class="fa fa-tag me-1"></i>
                                                <?= htmlspecialchars($b['kategori']) ?>
                                            </span>
                                        </td>
                                        <td>
                                            <i class="fa fa-user text-muted me-1"></i>
                                            <?= htmlspecialchars($b['penulis']) ?>
                                        </td>
                                        <td>
                                            <?php if (!empty($b['gambar'])): ?>
                                                <img src="../../uploads/<?= htmlspecialchars($b['gambar']) ?>"
                                                     width="60" height="40" class="rounded object-cover border" alt="gambar">
                                            <?php else: ?>
                                                <span class="text-muted small">
                                                    <i class="fa fa-image me-1"></i>Tidak ada
                                                </span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-center">
                                            <div class="btn-group" role="group">
                                                <a href="edit.php?id=<?= intval($b['id']); ?>"
                                                   class="btn btn-warning btn-sm me-1" title="Edit Berita">
                                                   <i class="fa fa-edit"></i>
                                                </a>
                                                <a href="kelola.php?hapus=<?= intval($b['id']); ?>"
                                                   onclick="return confirm('Yakin ingin menghapus berita \"<?= htmlspecialchars($b['judul']) ?>\"?')"
                                                   class="btn btn-danger btn-sm" title="Hapus Berita">
                                                   <i class="fa fa-trash"></i>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="6" class="text-center py-5">
                                        <div class="empty-state">
                                            <i class="fa fa-inbox fa-3x text-muted mb-3"></i>
                                            <h6 class="text-muted">Belum ada berita</h6>
                                            <p class="text-muted small mb-3">Mulai tambahkan artikel berita pertama Anda</p>
                                            <a href="tambah.php" class="btn btn-primary">
                                                <i class="fa fa-plus me-1"></i>Tambah Berita Pertama
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/dashboard.js"></script>
<script src="../assets/js/berita.js"></script>
</body>
</html>
<?php ob_end_flush(); ?>
