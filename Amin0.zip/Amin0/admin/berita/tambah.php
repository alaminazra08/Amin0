<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

ob_start();
session_start();
require_once __DIR__ . "/../../includes/config.php";

// ===== PROTEKSI AKSES ADMIN =====
if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../../login.php");
    exit;
}

// ===== PROSES SIMPAN BERITA =====
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['simpan'])) {
    $judul = $conn->real_escape_string(trim($_POST['judul'] ?? ''));
    $kategori = $conn->real_escape_string(trim($_POST['kategori'] ?? ''));
    $isi = $conn->real_escape_string(trim($_POST['isi'] ?? ''));
    $gambar = '';
    $penulis = $conn->real_escape_string($_POST['penulis'] ?? '');
    
    if (!empty($_FILES['gambar']['name'])) {
        $gambar = basename($_FILES['gambar']['name']);
        move_uploaded_file($_FILES['gambar']['tmp_name'], "../../uploads/" . $gambar);
    }

    $query = "INSERT INTO berita (judul, kategori, isi, gambar, penulis)
          VALUES ('$judul', '$kategori', '$isi', '$gambar', '$penulis')";

    mysqli_query($conn, $query);
    header("Location: kelola.php?success=1");
    exit;
}

// ===== GET KATEGORI =====
$kategoriList = [];
$result = mysqli_query($conn, "SELECT * FROM kategori ORDER BY nama_kategori ASC");
if ($result) {
    while ($k = mysqli_fetch_assoc($result)) {
        $kategoriList[] = $k;
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Tambah Berita | Admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/dashboard.css">
    <link rel="stylesheet" href="../assets/css/berita.css">
</head>
<body>
<div class="admin-wrapper">
    <div class="sidebar">
        <div class="d-flex align-items-center justify-content-between mb-3">
            <h4 class="mb-0">ADMIN PANEL</h4>
            <button onclick="toggleSidebar()" class="btn btn-sm btn-dark">☰</button>
        </div>
        
        <small class="text-uppercase text-secondary d-block mb-2">Menu Utama</small>
        <a href="../dashboard.php">
            <i class="fa fa-home"></i> <span>Dashboard</span>
        </a>
        <a href="../kategori.php">
            <i class="fa fa-tags me-2"></i> <span>Kategori</span>
        </a>

        <!-- MENU BERITA -->
        <a href="#" role="button" data-bs-toggle="collapse" data-bs-target="#menuBerita">
            <i class="fa fa-newspaper me-2"></i> <span>Berita</span>
            <i class="fa fa-chevron-down float-end"></i>
        </a>
        <div class="collapse show" id="menuBerita">
            <a href="tambah.php" class="ms-4 active">
                ➕ Tambah Berita
            </a>
            <a href="kelola.php" class="ms-4">
                📰 Data Berita
            </a>
        </div>
        
        <hr class="text-secondary">
        <small class="text-uppercase text-secondary d-block mb-2">Data</small>
        <a href="../newsletter.php">
            <i class="fa fa-envelope me-2"></i> <span>Data Newsletter</span>
        </a>
        <a href="../komentar.php">
            <i class="fa fa-comments me-2"></i> <span>Komentar</span>
        </a>
        <a href="../contact.php">
            <i class="fa fa-envelope me-2"></i> <span>Pesan Contact</span>
        </a>
        
        <hr class="text-secondary">
        <small class="text-uppercase text-secondary d-block mb-2">Lainnya</small>
        <a href="../../index.php">
            <i class="fa fa-globe me-2"></i><span>Lihat Website</span>
        </a>
        <a href="../../logout.php" class="text-danger">
            <i class="fa fa-sign-out-alt me-2"></i><span>Logout</span>
        </a>
    </div>

    <div class="main">
        <!-- HEADER -->
        <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
            <div>
                <h4 class="mb-1 fw-bold">
                    <i class="fa fa-plus-circle text-primary me-2"></i>
                    Tambah Berita Baru
                </h4>
                <p class="text-muted mb-0 small">Buat artikel berita baru untuk website</p>
            </div>
            <a href="kelola.php" class="btn btn-outline-secondary btn-sm shadow-sm">
                <i class="fa fa-arrow-left me-1"></i>Kembali ke Kelola Berita
            </a>
        </div>

        <!-- FORM CARD -->
        <div class="card border-0 shadow-sm">
            <div class="card-body p-4">
                <form method="POST" enctype="multipart/form-data" action="">
                    <div class="row g-4">
                        <!-- JUDUL -->
                        <div class="col-12">
                            <label class="form-label fw-semibold">
                                <i class="fa fa-heading text-primary me-1"></i>
                                Judul Berita
                            </label>
                            <input type="text" name="judul" class="form-control form-control-lg"
                                   placeholder="Masukkan judul berita yang menarik..." required>
                            <small class="text-muted">Judul akan ditampilkan sebagai headline artikel</small>
                        </div>

                        <!-- PENULIS & KATEGORI -->
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">
                                <i class="fa fa-user text-primary me-1"></i>
                                Nama Penulis
                            </label>
                            <input type="text" name="penulis" class="form-control"
                                   placeholder="Nama penulis artikel" required>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label fw-semibold">
                                <i class="fa fa-tags text-primary me-1"></i>
                                Kategori
                            </label>
                            <select name="kategori" class="form-select" required>
                                <option value="">-- Pilih Kategori --</option>
                                <?php foreach ($kategoriList as $k): ?>
                                    <option value="<?= htmlspecialchars($k['nama_kategori']) ?>">
                                        <?= htmlspecialchars($k['nama_kategori']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <!-- GAMBAR -->
                        <div class="col-12">
                            <label class="form-label fw-semibold">
                                <i class="fa fa-image text-primary me-1"></i>
                                Gambar Utama
                            </label>
                            <input type="file" name="gambar" class="form-control" accept="image/*">
                            <small class="text-muted">
                                <i class="fa fa-info-circle me-1"></i>
                                Format: JPG, PNG, GIF. Ukuran maksimal 2MB. Opsional, tapi disarankan untuk artikel yang lebih menarik.
                            </small>
                        </div>

                        <!-- ISI BERITA -->
                        <div class="col-12">
                            <label class="form-label fw-semibold">
                                <i class="fa fa-file-alt text-primary me-1"></i>
                                Isi Berita
                            </label>
                            <textarea name="isi" class="form-control" rows="12"
                                      placeholder="Tulis isi berita lengkap di sini... Gunakan paragraf yang jelas dan informatif." required></textarea>
                            <small class="text-muted">
                                <i class="fa fa-lightbulb me-1"></i>
                                Tip: Gunakan bahasa yang mudah dipahami, sertakan fakta yang akurat, dan buat artikel yang bermanfaat bagi pembaca.
                            </small>
                        </div>

                        <!-- BUTTONS -->
                        <div class="col-12">
                            <hr class="my-4">
                            <div class="d-flex gap-2 justify-content-end">
                                <a href="kelola.php" class="btn btn-outline-secondary">
                                    <i class="fa fa-times me-1"></i>Batal
                                </a>
                                <button name="simpan" class="btn btn-primary px-4" type="submit">
                                    <i class="fa fa-save me-1"></i>Simpan Berita
                                </button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/dashboard.js"></script>
<script src="../assets/js/berita.js"></script>
</body>
</html>
<?php ob_end_flush(); ?>
