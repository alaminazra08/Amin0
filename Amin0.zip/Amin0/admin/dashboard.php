<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

ob_start();
session_start();
require_once __DIR__ . "/../includes/config.php";

// Pastikan tabel kategori ada sebelum digunakan
mysqli_query($conn, "CREATE TABLE IF NOT EXISTS kategori (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama_kategori VARCHAR(255) NOT NULL UNIQUE
)");

// ===== PROTEKSI AKSES ADMIN =====
if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

// ===== TOTAL BERITA =====
$totalBerita = 0;
$qTotal = mysqli_query($conn, "SELECT COUNT(*) AS total FROM berita");
if ($qTotal) {
    $totalBerita = mysqli_fetch_assoc($qTotal)['total'];
}

// ===== TOTAL KOMENTAR =====
$totalKomentar = 0;
$qKomen = mysqli_query($conn, "SELECT COUNT(*) as total FROM komentar");
if ($qKomen) {
    $totalKomentar = mysqli_fetch_assoc($qKomen)['total'];
}

// ===== TOTAL SUBSCRIBER =====
$totalSubscriber = 0;
$qSub = mysqli_query($conn, "SELECT COUNT(*) AS total FROM newsletter");
if ($qSub) {
    $totalSubscriber = mysqli_fetch_assoc($qSub)['total'];
}

// ===== GRAFIK BERITA PER BULAN =====
$dataBulan = [];
$dataTotal = [];
$grafik = mysqli_query($conn, "
    SELECT MONTH(tanggal) as bulan, COUNT(*) as total
    FROM berita
    GROUP BY MONTH(tanggal)
");
if ($grafik) {
    while ($g = mysqli_fetch_assoc($grafik)) {
        $namaBulan = date('M', mktime(0, 0, 0, $g['bulan'], 1));
        $dataBulan[] = $namaBulan;
        $dataTotal[] = $g['total'];
    }
}


// ===== GET BERITA TERBARU =====
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Admin Dashboard | Kabar Nusantara</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<link rel="stylesheet" href="assets/css/dashboard.css">
</head>

<body>

<div class="admin-wrapper">

    <!-- SIDEBAR -->
    <div class="sidebar">
        <div class="d-flex align-items-center justify-content-between mb-3">
    <h4 class="mb-0">ADMIN PANEL</h4>

    <button onclick="toggleSidebar()" class="btn btn-sm btn-dark">
        ☰
    </button>
</div>

        <!-- MENU UTAMA -->
        <small class="text-uppercase text-secondary d-block mb-2">Menu Utama</small>
            

        <a class="active" href="dashboard.php">
            <i class="fa fa-home"></i> <span>Dashboard</span>
        </a>
        <a href="kategori.php">
    <i class="fa fa-tags me-2"></i> <span>Kategori</span>
</a>

     <!-- MENU KELOLA BERITA -->
<a href="#" role="button"
   data-bs-toggle="collapse" data-bs-target="#menuBerita">
    <i class="fa fa-newspaper me-2"></i> <span>Berita</span>
    <i class="fa fa-chevron-down float-end"></i>
</a>

<div class="collapse" id="menuBerita">
    <a href="berita/tambah.php" class="ms-4">
        ➕ Tambah Berita
    </a>
    <a href="berita/kelola.php" class="ms-4">
        📰 Data Berita
    </a>
</div>
        <hr class="text-secondary">

        <!-- DATA -->
        <small class="text-uppercase text-secondary d-block mb-2">Data</small>

        <a href="newsletter.php">
            <i class="fa fa-envelope me-2"></i> <span>Data Newsletter</span>
        </a>
        <a href="komentar.php">
            <i class="fa fa-comments me-2"></i> <span>Komentar</span>
        </a>
        <a href="contact.php">
    <i class="fa fa-envelope me-2"></i> <span>Pesan Contact</span>
</a>
        <hr class="text-secondary">

        <!-- LAINNYA -->
        <small class="text-uppercase text-secondary d-block mb-2">Lainnya</small>

        <a href="../index.php">
            <i class="fa fa-globe me-2"></i><span>Lihat Website</span>
        </a>

        <a href="../logout.php" class="text-danger">
            <i class="fa fa-sign-out-alt me-2"></i><span>Logout</span>
        </a>
    </div>
<!-- MAIN -->
<div class="main">



    <?php if (true): ?>

<div class="box d-flex justify-content-between align-items-center flex-wrap bg-gradient-primary text-white rounded-4 p-4 shadow-lg" style="min-height: 200px;">

    <!-- KIRI -->
    <div class="flex-grow-1">
        <h3 class="fw-bold mb-2" style="color: rgba(0, 0, 0, 0.9)!important;">
            <i class="fa fa-gauge-high me-3"></i>
            Selamat Datang, <?= htmlspecialchars($_SESSION['user'] ?? 'Admin', ENT_QUOTES); ?>!
        </h3>

        <p class="mb-3 opacity-75" style="color: rgba(0, 0, 0, 0.9) !important;">
            Kelola portal berita Anda dengan mudah dan efisien. Pantau performa, kelola konten, dan interaksi pengguna.
        </p>

        <div class="d-flex flex-wrap gap-3">
            <span class="badge bg-white text-primary px-3 py-2 shadow-sm">
                <i class="fa fa-calendar me-1"></i>
                <span id="tanggal"></span>
            </span>
            <span class="badge bg-white text-success px-3 py-2 shadow-sm">
                <i class="fa fa-server me-1"></i> Sistem Online
            </span>
        </div>
    </div>

    <!-- KANAN (JAM) -->
    <div class="text-end mt-3 mt-lg-0">
        <div class="clock-box bg-white text-dark px-4 py-3 rounded-3 shadow-sm">
            <div class="small text-muted mb-1">Waktu Sekarang</div>
            <div class="h4 mb-0 fw-bold">
                <i class="fa fa-clock me-2 text-primary"></i>
                <span id="jam"></span>
            </div>
        </div>
    </div>

</div>



<!-- STATUS SISTEM -->
<div class="box fade-in mt-4">
    <!-- HEADER -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h5 class="fw-bold mb-1">
                <i class="fa fa-chart-line text-primary me-2"></i>
                Statistik Sistem
            </h5>
            <p class="text-muted mb-0 small">Ringkasan performa dan aktivitas portal berita</p>
        </div>

        <span class="badge bg-success px-3 py-2 shadow-sm">
            <span class="dot-live"></span> Live Monitoring
        </span>
    </div>

    <!-- CONTENT -->
    <div class="row g-4">

        <!-- BERITA -->
        <div class="col-lg-3 col-md-6">
            <div class="card h-100 border-0 shadow-sm hover-lift">
                <div class="card-body text-center p-4">
                    <div class="icon-wrapper bg-primary bg-opacity-10 text-primary rounded-circle mx-auto mb-3" style="width: 60px; height: 60px; display: flex; align-items: center; justify-content: center;">
                        <i class="fa fa-newspaper fa-2x"></i>
                    </div>
                    <h6 class="text-muted mb-2">Total Berita</h6>
                    <h2 class="fw-bold text-primary mb-1 counter" data-target="<?= intval($totalBerita); ?>">0</h2>
                    <small class="text-muted">Artikel dipublikasikan</small>
                </div>
            </div>
        </div>

        <!-- KOMENTAR -->
        <div class="col-lg-3 col-md-6">
            <div class="card h-100 border-0 shadow-sm hover-lift">
                <div class="card-body text-center p-4">
                    <div class="icon-wrapper bg-warning bg-opacity-10 text-warning rounded-circle mx-auto mb-3" style="width: 60px; height: 60px; display: flex; align-items: center; justify-content: center;">
                        <i class="fa fa-comments fa-2x"></i>
                    </div>
                    <h6 class="text-muted mb-2">Total Komentar</h6>
                    <h2 class="fw-bold text-warning mb-1 counter" data-target="<?= intval($totalKomentar); ?>">0</h2>
                    <small class="text-muted">Interaksi pengguna</small>
                </div>
            </div>
        </div>

        <!-- SUBSCRIBER -->
        <div class="col-lg-3 col-md-6">
            <div class="card h-100 border-0 shadow-sm hover-lift">
                <div class="card-body text-center p-4">
                    <div class="icon-wrapper bg-success bg-opacity-10 text-success rounded-circle mx-auto mb-3" style="width: 60px; height: 60px; display: flex; align-items: center; justify-content: center;">
                        <i class="fa fa-envelope fa-2x"></i>
                    </div>
                    <h6 class="text-muted mb-2">Total Subscriber</h6>
                    <h2 class="fw-bold text-success mb-1 counter" data-target="<?= intval($totalSubscriber); ?>">0</h2>
                    <small class="text-muted">Pengguna berlangganan</small>
                </div>
            </div>
        </div>

        <!-- KATEGORI -->
        <div class="col-lg-3 col-md-6">
            <div class="card h-100 border-0 shadow-sm hover-lift">
                <div class="card-body text-center p-4">
                    <div class="icon-wrapper bg-info bg-opacity-10 text-info rounded-circle mx-auto mb-3" style="width: 60px; height: 60px; display: flex; align-items: center; justify-content: center;">
                        <i class="fa fa-tags fa-2x"></i>
                    </div>
                    <h6 class="text-muted mb-2">Total Kategori</h6>
                    <?php
                    $totalKategori = 0;
                    $qKat = mysqli_query($conn, "SELECT COUNT(*) AS total FROM kategori");
                    if ($qKat) {
                        $totalKategori = mysqli_fetch_assoc($qKat)['total'];
                    }
                    ?>
                    <h2 class="fw-bold text-info mb-1 counter" data-target="<?= intval($totalKategori); ?>">0</h2>
                    <small class="text-muted">Kategori berita</small>
                </div>
            </div>
        </div>
    </div>

    <!-- FOOTER -->
    <div class="d-flex align-items-center justify-content-between mt-4 pt-3 border-top text-muted small">
        <div>
            <i class="fa fa-wifi me-1 text-success"></i>
            Sistem berjalan normal
        </div>

        <div class="text-center flex-grow-1 mx-3">
            <div class="marquee-wrapper">
                <div class="marquee">
                    🚀 Portal berita aktif • <?= intval($totalBerita); ?> berita • <?= intval($totalSubscriber); ?> subscriber • <?= intval($totalKomentar); ?> komentar • <?= intval($totalKategori); ?> kategori •
                </div>
            </div>
        </div>

        <div>
            Update terakhir:
            <b>
                <?php
                $last = mysqli_query($conn, "SELECT MAX(tanggal) as terakhir FROM berita");
                if ($last) {
                    $d = mysqli_fetch_assoc($last);
                    echo $d['terakhir'] ? date('d M Y', strtotime($d['terakhir'])) : '-';
                } else {
                    echo '-';
                }
                ?>
            </b>
        </div>
    </div>
</div>

<!-- BERITA TERBARU -->
<div class="box mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
        <div>
            <h5 class="mb-1 fw-bold">
                <i class="fa fa-newspaper text-primary me-2"></i>
                Berita Terbaru
            </h5>
            <p class="text-muted mb-0 small">Artikel terbaru yang telah dipublikasikan</p>
        </div>

        <a href="berita/kelola.php" class="btn btn-primary btn-sm shadow-sm">
            <i class="fa fa-list me-1"></i>
            Kelola Berita (<?= intval($totalBerita); ?>)
        </a>
    </div>

    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0 shadow-sm rounded">
            <thead class="table-light">
                <tr>
                    <th width="5%">No</th>
                    <th>Judul</th>
                    <th>Kategori</th>
                    <th>Gambar</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $recent = mysqli_query($conn, "SELECT * FROM berita ORDER BY id DESC LIMIT 5");
                $no = 1;
                while ($r = mysqli_fetch_assoc($recent)):
                ?>
                    <tr>
                        <td class="text-muted fw-semibold"><?= $no++ ?></td>
                        <td>
                            <div class="fw-semibold text-truncate" style="max-width: 300px;" title="<?= htmlspecialchars($r['judul']) ?>">
                                <?= htmlspecialchars($r['judul']) ?>
                            </div>
                            <small class="text-muted">
                                <i class="fa fa-calendar me-1"></i>
                                <?= date('d M Y', strtotime($r['tanggal'])) ?>
                            </small>
                        </td>
                        <td>
                            <span class="badge bg-secondary">
                                <?= htmlspecialchars($r['kategori']) ?>
                            </span>
                        </td>
                        <td>
                            <?php if (!empty($r['gambar'])): ?>
                                <img src="/Amin0/uploads/<?= htmlspecialchars($r['gambar']) ?>"
                                     width="60" height="40" class="rounded object-cover" alt="gambar">
                            <?php else: ?>
                                <span class="text-muted small">Tidak ada</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="berita/edit.php?id=<?= intval($r['id']); ?>"
                               class="btn btn-warning btn-sm me-1">
                               <i class="fa fa-edit"></i>
                            </a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- ======================================================
     📊 STATISTIK BERITA PER BULAN (UI MODERN BLOCK)
====================================================== -->
<div class="box mt-4">
    <!-- HEADER -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h5 class="mb-1 fw-bold">
                <i class="fa fa-chart-bar text-primary me-2"></i>
                Statistik Berita Bulanan
            </h5>
            <p class="text-muted mb-0 small">Grafik jumlah berita yang dipublikasikan per bulan</p>
        </div>
        <span class="badge bg-primary px-3 py-2 shadow-sm">Data Real-time</span>
    </div>

    <!-- CHART -->
    <div class="bg-light rounded-4 p-4">
        <canvas id="chartBerita" style="max-height: 350px;"></canvas>
    </div>
</div>

<!-- AKSI CEPAT -->
<div class="box mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h5 class="mb-1 fw-bold">
                <i class="fa fa-bolt text-warning me-2"></i>
                Aksi Cepat
            </h5>
            <p class="text-muted mb-0 small">Navigasi cepat ke fitur utama</p>
        </div>
    </div>

    <div class="row g-3">
        <div class="col-lg-3 col-md-6">
            <a href="berita/tambah.php" class="card h-100 border-0 shadow-sm hover-lift text-decoration-none">
                <div class="card-body text-center p-4">
                    <div class="icon-wrapper bg-primary bg-opacity-10 text-primary rounded-circle mx-auto mb-3" style="width: 50px; height: 50px; display: flex; align-items: center; justify-content: center;">
                        <i class="fa fa-plus fa-lg"></i>
                    </div>
                    <h6 class="text-dark mb-1">Tambah Berita</h6>
                    <small class="text-muted">Buat artikel baru</small>
                </div>
            </a>
        </div>

        <div class="col-lg-3 col-md-6">
            <a href="berita/kelola.php" class="card h-100 border-0 shadow-sm hover-lift text-decoration-none">
                <div class="card-body text-center p-4">
                    <div class="icon-wrapper bg-success bg-opacity-10 text-success rounded-circle mx-auto mb-3" style="width: 50px; height: 50px; display: flex; align-items: center; justify-content: center;">
                        <i class="fa fa-list fa-lg"></i>
                    </div>
                    <h6 class="text-dark mb-1">Kelola Berita</h6>
                    <small class="text-muted">Edit & hapus artikel</small>
                </div>
            </a>
        </div>

        <div class="col-lg-3 col-md-6">
            <a href="komentar.php" class="card h-100 border-0 shadow-sm hover-lift text-decoration-none">
                <div class="card-body text-center p-4">
                    <div class="icon-wrapper bg-warning bg-opacity-10 text-warning rounded-circle mx-auto mb-3" style="width: 50px; height: 50px; display: flex; align-items: center; justify-content: center;">
                        <i class="fa fa-comments fa-lg"></i>
                    </div>
                    <h6 class="text-dark mb-1">Komentar</h6>
                    <small class="text-muted">Moderasi komentar</small>
                </div>
            </a>
        </div>

        <div class="col-lg-3 col-md-6">
            <a href="newsletter.php" class="card h-100 border-0 shadow-sm hover-lift text-decoration-none">
                <div class="card-body text-center p-4">
                    <div class="icon-wrapper bg-info bg-opacity-10 text-info rounded-circle mx-auto mb-3" style="width: 50px; height: 50px; display: flex; align-items: center; justify-content: center;">
                        <i class="fa fa-envelope fa-lg"></i>
                    </div>
                    <h6 class="text-dark mb-1">Newsletter</h6>
                    <small class="text-muted">Kelola subscriber</small>
                </div>
            </a>
        </div>
    </div>
</div>

    <?php endif; ?>


<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    // Pass chart data dari PHP ke JavaScript
    window.dataBulanChart = <?= json_encode($dataBulan); ?>;
    window.dataTotalChart = <?= json_encode($dataTotal); ?>;
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/dashboard.js"></script>
</body>
</html>
<?php ob_end_flush(); ?>