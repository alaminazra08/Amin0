<?php
session_start();
require_once "../includes/config.php";

/* =============================
   PROTEKSI ADMIN
============================= */
if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

/* =============================
   VALIDASI ID
============================= */
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: /Amin0/admin/dashboard.php?page=kelola");
    exit;
}

$id = (int) $_GET['id'];

/* =============================
   AMBIL DATA LAMA
============================= */
$stmt = $conn->prepare("SELECT * FROM berita WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$data = $stmt->get_result()->fetch_assoc();

if (!$data) {
    header("Location: /Amin0/admin/dashboard.php?page=kelola");
    exit;
}

/* =============================
   PROSES UPDATE
============================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update'])) {

    $judul   = trim($_POST['judul'] ?? '');
    $kategori = trim($_POST['kategori'] ?? '');
    $isi     = trim($_POST['isi'] ?? '');
    $gambar  = $data['gambar'];

    if (!empty($_FILES['gambar']['name'])) {
        $fileName = time() . '_' . basename($_FILES['gambar']['name']);
        move_uploaded_file($_FILES['gambar']['tmp_name'], "../uploads/" . $fileName);
        $gambar = $fileName;
    }

    // UPDATE (AMAN)
    $stmt = $conn->prepare("UPDATE berita SET judul=?, kategori=?, isi=?, gambar=? WHERE id=?");
    $stmt->bind_param("ssssi", $judul, $kategori, $isi, $gambar, $id);
    $stmt->execute();

    header("Location: /Amin0/admin/dashboard.php?page=kelola");
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Edit Berita</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body{
    background: linear-gradient(135deg, #eef2f7, #dfe9f3);
    min-height:100vh;
    font-family: 'Segoe UI', sans-serif;
}
.edit-wrapper{
    max-width: 1200px;
    margin: 40px auto;
    padding: 0 15px;
}
.card{
    border: none;
    border-radius: 20px;
    overflow: hidden;
    box-shadow: 0 15px 40px rgba(0,0,0,0.08);
}
.card-header{
    background: linear-gradient(135deg, #0d6efd, #0b5ed7);
    color: white;
    padding: 20px 30px;
}
.card-body{
    padding: 35px;
    background:white;
}
.form-control {
    border-radius: 12px;
    padding: 10px;
}
.preview-img {
    max-width: 320px;
    border-radius: 14px;
}

.form-control:focus {
    border-color: #3b82f6;
    box-shadow: 0 0 0 3px rgba(59,130,246,0.2);
}
</style>
</head>

<body>

<div class="container-fluid edit-wrapper">
    <div class="card">
        
       <div class="alert alert-info">
    Edit berita ID: <b><?= $id ?></b>
</div>
        <div class="card-body">
            <form method="POST" enctype="multipart/form-data">

                <!-- JUDUL -->
                <div class="mb-4">
                    <label class="form-label">Judul</label>
                    <input type="text" name="judul" class="form-control"
                    value="<?= htmlspecialchars($data['judul'], ENT_QUOTES); ?>" required>
                </div>

                <div class="mb-4">
                    <label class="form-label">Kategori</label>

                    <select id="kategori" name="kategori" class="form-control mb-3" required>
                        <option value="">-- Pilih Kategori --</option>

                        <?php
                        $kategoriQuery = mysqli_query($conn, "SELECT * FROM kategori ORDER BY nama_kategori ASC");

                        if (!$kategoriQuery) {
                            echo "<option value=''>Error kategori</option>";
                        } elseif (mysqli_num_rows($kategoriQuery) === 0) {
                            echo "<option value=''>Belum ada kategori</option>";
                        } else {
                            while ($k = mysqli_fetch_assoc($kategoriQuery)) :
                        ?>
                                <option value="<?= htmlspecialchars($k['nama_kategori'], ENT_QUOTES) ?>"
                                    <?= ($data['kategori'] ?? '') === $k['nama_kategori'] ? 'selected' : ''; ?>>
                                    <?= htmlspecialchars($k['nama_kategori']) ?>
                                </option>
                        <?php
                            endwhile;
                        }
                        ?>
                    </select>

                    <div class="mt-2">
                        <span id="badgeKategori" class="badge"></span>
                    </div>
                </div>

                <!-- GAMBAR SAAT INI -->
                <div class="mb-4">
                    <label class="form-label">Gambar Saat Ini</label>
                    <div class="preview-box text-center">
                        <?php if (!empty($data['gambar'])): ?>
                            <img src="../uploads/<?= htmlspecialchars($data['gambar'], ENT_QUOTES); ?>" class="preview-img" alt="Gambar Berita">
                        <?php else: ?>
                            <p class="text-muted">Belum ada gambar</p>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- GANTI GAMBAR -->
                <div class="mb-4">
                    <label class="form-label">Ganti Gambar</label>
                    <input type="file" name="gambar" class="form-control">
                    <small class="text-muted">Kosongkan jika tidak ingin mengganti</small>
                </div>

                <!-- ISI -->
                <div class="mb-4">
                    <label class="form-label">Isi Berita</label>
                    <textarea name="isi" class="form-control" rows="6" required><?= htmlspecialchars($data['isi'], ENT_QUOTES); ?></textarea>
                </div>

                <!-- BUTTON -->
                <div class="d-flex gap-3">
                    <button name="update" class="btn btn-primary">
                        💾 Simpan
                    </button>

                    

                    <a href="/Amin0/admin/dashboard.php?page=kelola" class="btn btn-secondary">
                        Batal
                    </a>
                </div>

            </form>
        </div>
    </div>
</div>



<script>
function updateBadge() {
    const select = document.getElementById("kategori");
    const text = select.options[select.selectedIndex].text.trim().toLowerCase();
    const badge = document.getElementById("badgeKategori");

    // reset total class
    badge.className = "";
    badge.classList.add("badge");

    let warna = "bg-secondary";

    switch (text) {
        case "politik":
            warna = "bg-danger";
            break;
        case "olahraga":
            warna = "bg-success";
            break;
        case "teknologi":
            warna = "bg-info";
            break;
        case "pendidikan":
            warna = "bg-warning text-dark";
            break;
        case "hiburan":
            warna = "bg-dark";
            break;
        default:
            warna = "bg-primary"; // kalau tidak cocok
    }

    badge.classList.add(...warna.split(" "));
    badge.innerText = text;
}

// Jalankan saat load & saat berubah
document.getElementById("kategori").addEventListener("change", updateBadge);
window.onload = updateBadge;
</script>

</body>
</html>