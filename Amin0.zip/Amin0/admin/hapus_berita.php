<?php
session_start();
require_once __DIR__ . '/../includes/config.php';

if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit;
}

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Location: dashboard.php?page=kelola');
    exit;
}

$id = (int) $_GET['id'];

$stmt = $conn->prepare('SELECT gambar FROM berita WHERE id = ?');
$stmt->bind_param('i', $id);
$stmt->execute();
$result = $stmt->get_result();
$news = $result->fetch_assoc();
$stmt->close();

if ($news) {
    if (!empty($news['gambar'])) {
        $filePath = __DIR__ . '/../uploads/' . $news['gambar'];
        if (is_file($filePath)) {
            unlink($filePath);
        }
    }

    $stmt = $conn->prepare('DELETE FROM berita WHERE id = ?');
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $stmt->close();
}

header('Location: dashboard.php?page=kelola');
exit;
