<?php
session_start();
require_once __DIR__ . '/../includes/config.php';

// Pastikan hanya admin yang dapat menghapus data newsletter
if (!isset($_SESSION['user']) || ($_SESSION['role'] ?? '') !== 'admin') {
    header('Location: ../login.php');
    exit;
}

// Validasi input ID
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Location: dashboard.php?page=newsletter');
    exit;
}

$id = intval($_GET['id']);

$stmt = $conn->prepare('DELETE FROM newsletter WHERE id = ?');
$stmt->bind_param('i', $id);
$stmt->execute();
$stmt->close();

header('Location: dashboard.php?page=newsletter');
exit;