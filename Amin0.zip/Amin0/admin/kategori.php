<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

ob_start();
session_start();
require_once __DIR__ . "/../includes/config.php";

// Pastikan tabel kategori ada sebelum digunakan
mysqli_query($conn, "CREATE TABLE IF NOT EXISTS kategori (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama_kategori VARCHAR(255) NOT NULL UNIQUE
)");

// ===== PROTEKSI AKSES ADMIN =====
if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

// ===== PROSES SIMPAN KATEGORI =====
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['nama_kategori'])) {
    $namaKategori = $conn->real_escape_string(trim($_POST['nama_kategori'] ?? ''));
    if ($namaKategori !== '') {
        mysqli_query($conn, "INSERT IGNORE INTO kategori (nama_kategori) VALUES ('$namaKategori')");
    }
    header("Location: kategori.php");
    exit;
}

// ===== PROSES HAPUS KATEGORI =====
if (isset($_GET['hapus_kategori'])) {
    $id = intval($_GET['hapus_kategori']);
    mysqli_query($conn, "DELETE FROM kategori WHERE id=$id");
    header("Location: kategori.php");
    exit;
}

// ===== PROSES EDIT KATEGORI =====
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_kategori'])) {
    $id = intval($_POST['id']);
    $nama = $conn->real_escape_string(trim($_POST['nama_kategori']));
    mysqli_query($conn, "UPDATE kategori SET nama_kategori='$nama' WHERE id=$id");
    header("Location: kategori.php");
    exit;
}

// ===== GET SEMUA KATEGORI =====
$search = trim($_GET['q'] ?? '');
$whereClause = '';
if ($search !== '') {
    $safeSearch = $conn->real_escape_string($search);
    $whereClause = "WHERE nama_kategori LIKE '%$safeSearch%'";
}

$kategoriList = [];
$result = mysqli_query($conn, "SELECT * FROM kategori $whereClause ORDER BY id DESC");
if ($result) {
    while ($k = mysqli_fetch_assoc($result)) {
        $kategoriList[] = $k;
    }
}

// ===== TOTAL KATEGORI =====
$totalKategori = count($kategoriList);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Kelola Kategori | Admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="assets/css/dashboard.css">
    <link rel="stylesheet" href="assets/css/kategori.css">
</head>
<body class="kategori-page">
<div class="admin-wrapper">
    <div class="sidebar">
    <div class="d-flex align-items-center justify-content-between mb-3">
        <h4 class="mb-0">ADMIN PANEL</h4>
        <button onclick="toggleSidebar()" class="btn btn-sm btn-dark">☰</button>
    </div>

    <!-- MENU UTAMA -->
    <small class="text-uppercase text-secondary d-block mb-2">Menu Utama</small>

    <a href="dashboard.php">
        <i class="fa fa-home"></i> <span>Dashboard</span>
    </a>

    <a href="kategori.php" class="active">
        <i class="fa fa-tags me-2"></i> <span>Kategori</span>
    </a>

    <!-- MENU BERITA -->
    <a href="#" data-bs-toggle="collapse" data-bs-target="#menuBerita">
        <i class="fa fa-newspaper me-2"></i> <span>Berita</span>
        <i class="fa fa-chevron-down float-end"></i>
    </a>

    <div class="collapse" id="menuBerita">
        <a href="berita/tambah.php" class="ms-4">
            ➕ Tambah Berita
        </a>
        <a href="berita/kelola.php" class="ms-4">
            📰 Data Berita
        </a>
    </div>

    <hr class="text-secondary">

    <!-- DATA -->
    <small class="text-uppercase text-secondary d-block mb-2">Data</small>

    <a href="newsletter.php">
        <i class="fa fa-envelope me-2"></i> <span>Data Newsletter</span>
    </a>

    <a href="komentar.php">
        <i class="fa fa-comments me-2"></i> <span>Komentar</span>
    </a>

    <a href="contact.php">
        <i class="fa fa-envelope me-2"></i> <span>Pesan Contact</span>
    </a>

    <hr class="text-secondary">

    <!-- LAINNYA -->
    <small class="text-uppercase text-secondary d-block mb-2">Lainnya</small>

    <a href="../index.php">
        <i class="fa fa-globe me-2"></i><span>Lihat Website</span>
    </a>

    <a href="../logout.php" class="text-danger">
        <i class="fa fa-sign-out-alt me-2"></i><span>Logout</span>
    </a>
</div>

    <div class="main">
        <div class="box">
            <div class="kategori-hero">
                <div>
                    <h4 class="mb-2"><i class="fa fa-tags me-2"></i>Kelola Kategori</h4>
                    <p class="text-muted mb-0">Rancang struktur kategori yang rapi dan mudah diatur.</p>
                </div>
                <div class="kategori-stats">
                    <span class="badge badge-pill stat-pill">Total kategori: <?= $totalKategori ?></span>
                </div>
            </div>

            <div class="card shadow-sm border-0 rounded-4 mb-4 kategori-panel">
                <div class="card-body p-4">
                    <div class="d-flex flex-column flex-lg-row justify-content-between gap-3 align-items-start align-items-lg-center mb-4">
                        <div>
                            <h6 class="mb-1">Tambah Kategori Baru</h6>
                            <p class="text-muted mb-0">Tambahkan topik baru untuk membantu navigasi dan pengelompokan konten.</p>
                        </div>
                        <span class="badge bg-secondary text-white px-3 py-2">Kategori aktif: <?= $totalKategori ?></span>
                    </div>

                    <form method="POST" class="row g-3">
                        <div class="col-lg-9">
                            <label class="form-label">Nama Kategori</label>
                            <input type="text" name="nama_kategori" class="form-control form-control-lg" placeholder="Masukkan nama kategori baru" required>
                        </div>
                        <div class="col-lg-3 d-grid">
                            <button type="submit" class="btn btn-primary btn-lg">
                                <i class="fa fa-plus-circle me-1"></i> Tambah Kategori
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <div class="card shadow-sm border-0 rounded-4 kategori-table-card">
                <div class="card-header d-flex flex-column flex-md-row align-items-md-center justify-content-between bg-white border-0 py-3">
                    <div>
                        <h6 class="mb-1">Daftar Kategori</h6>
                        <p class="text-muted mb-0">Kelola kategori yang sudah dibuat dan hapus yang tidak lagi relevan.</p>
                    </div>

                    <form method="GET" class="d-flex flex-column flex-sm-row gap-2 align-items-center">
                        <div class="input-group input-group-sm">
                            <span class="input-group-text bg-white border-end-0"><i class="fa fa-search text-muted"></i></span>
                            <input type="search" name="q" class="form-control border-start-0" placeholder="Cari kategori..." value="<?= htmlspecialchars($search, ENT_QUOTES); ?>">
                        </div>
                        <button type="submit" class="btn btn-outline-primary btn-sm">Cari</button>
                        <a href="kategori.php" class="btn btn-outline-secondary btn-sm">Reset</a>
                    </form>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-kategori table-hover align-middle mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th width="5%">No</th>
                                    <th>Nama Kategori</th>
                                    <th width="20%">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!empty($kategoriList)): ?>
                                    <?php $no = 1; ?>
                                    <?php foreach ($kategoriList as $k): ?>
                                        <tr>
                                            <td class="text-muted"><?= $no++ ?></td>
                                            <td class="fw-semibold text-capitalize"><?= htmlspecialchars($k['nama_kategori'], ENT_QUOTES) ?></td>
                                            <td class="action-wrap">
                                                <a href="kategori.php?hapus_kategori=<?= $k['id'] ?>"
                                                   onclick="return confirm('Hapus kategori ini?')"
                                                   class="btn btn-outline-danger btn-sm">
                                                   <i class="fa fa-trash me-1"></i>Hapus
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="3">
                                            <div class="empty-state-kategori">
                                                <i class="fa fa-folder-open"></i>
                                                <h6>Tidak ada kategori yang ditemukan</h6>
                                                <p>Coba tambahkan kategori baru atau gunakan kata kunci lain.</p>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/dashboard.js"></script>
<script src="assets/js/kategori.js"></script>
</body>
</html>
<?php ob_end_flush(); ?>
