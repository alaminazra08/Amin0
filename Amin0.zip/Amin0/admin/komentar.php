<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

ob_start();
session_start();
require_once __DIR__ . "/../includes/config.php";

// ===== PROTEKSI AKSES ADMIN =====
if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

// ===== PROSES HAPUS KOMENTAR =====
if (isset($_GET['hapus_komentar'])) {
    $id = intval($_GET['hapus_komentar']);
    mysqli_query($conn, "DELETE FROM komentar WHERE id=$id");
    header("Location: komentar.php");
    exit;
}

// ===== GET SEMUA KOMENTAR =====
$search = trim($_GET['q'] ?? '');
$whereClause = '';
if ($search !== '') {
    $safeSearch = $conn->real_escape_string($search);
    $whereClause = "WHERE komentar.nama LIKE '%$safeSearch%' OR komentar.isi LIKE '%$safeSearch%' OR berita.judul LIKE '%$safeSearch%'";
}

$komentarList = [];
$query = "SELECT komentar.*, berita.judul FROM komentar
          JOIN berita ON komentar.berita_id = berita.id
          $whereClause
          ORDER BY komentar.id DESC";
$result = mysqli_query($conn, $query);
if ($result) {
    while ($k = mysqli_fetch_assoc($result)) {
        $komentarList[] = $k;
    }
}

$lastComment = mysqli_query($conn, "SELECT MAX(tanggal) AS latest FROM komentar");
$latestCommentDate = $lastComment ? mysqli_fetch_assoc($lastComment)['latest'] : null;

// ===== TOTAL KOMENTAR =====
$totalKomentar = count($komentarList);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Kelola Komentar | Admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="assets/css/dashboard.css">
    <link rel="stylesheet" href="assets/css/komentar.css">
</head>
<body>
<div class="admin-wrapper">
    <div class="sidebar">
    <div class="d-flex align-items-center justify-content-between mb-3">
        <h4 class="mb-0">ADMIN PANEL</h4>
        <button onclick="toggleSidebar()" class="btn btn-sm btn-dark">☰</button>
    </div>

    <!-- MENU UTAMA -->
    <small class="text-uppercase text-secondary d-block mb-2">Menu Utama</small>

    <a href="dashboard.php">
        <i class="fa fa-home"></i> <span>Dashboard</span>
    </a>

    <a href="kategori.php">
        <i class="fa fa-tags me-2"></i> <span>Kategori</span>
    </a>

    <!-- MENU BERITA -->
    <a href="#" data-bs-toggle="collapse" data-bs-target="#menuBerita">
        <i class="fa fa-newspaper me-2"></i> <span>Berita</span>
        <i class="fa fa-chevron-down float-end"></i>
    </a>

    <div class="collapse" id="menuBerita">
        <a href="berita/tambah.php" class="ms-4">
            ➕ Tambah Berita
        </a>
        <a href="berita/kelola.php" class="ms-4">
            📰 Data Berita
        </a>
    </div>

    <hr class="text-secondary">

    <!-- DATA -->
    <small class="text-uppercase text-secondary d-block mb-2">Data</small>

    <a href="newsletter.php">
        <i class="fa fa-envelope me-2"></i> <span>Data Newsletter</span>
    </a>

    <a href="komentar.php" class="active">
        <i class="fa fa-comments me-2"></i><span>Komentar</span>
    </a>

    <a href="contact.php">
        <i class="fa fa-envelope me-2"></i> <span>Pesan Contact</span>
    </a>

    <hr class="text-secondary">

    <!-- LAINNYA -->
    <small class="text-uppercase text-secondary d-block mb-2">Lainnya</small>

    <a href="../index.php">
        <i class="fa fa-globe me-2"></i><span>Lihat Website</span>
    </a>

    <a href="../logout.php" class="text-danger">
        <i class="fa fa-sign-out-alt me-2"></i><span>Logout</span>
    </a>
</div>

    <div class="main">
        <div class="box">
            <div class="row align-items-center mb-4">
                <div class="col-md-7">
                    <h4 class="mb-1"><i class="fa fa-comments me-2"></i>Kelola Komentar</h4>
                    <p class="text-muted mb-0">Pantau dan moderasi komentar pengguna secara efektif.</p>
                </div>
                <div class="col-md-5 text-md-end mt-3 mt-md-0">
                    <span class="badge bg-success px-3 py-2 me-2">Total: <?= $totalKomentar ?></span>
                    <span class="text-muted small">Terakhir: <?= $latestCommentDate ? date('d M Y H:i', strtotime($latestCommentDate)) : '-' ?></span>
                </div>
            </div>

            <div class="card shadow-sm border-0 rounded-4 mb-4">
                <div class="card-body p-4">
                    <form method="GET" class="row g-2 align-items-center mb-4">
                        <div class="col-lg-8">
                            <div class="input-group">
                                <span class="input-group-text bg-white border-end-0"><i class="fa fa-search text-muted"></i></span>
                                <input type="search" name="q" class="form-control border-start-0" placeholder="Cari nama, komentar, atau judul berita..." value="<?= htmlspecialchars($search, ENT_QUOTES); ?>">
                            </div>
                        </div>
                        <div class="col-lg-4 d-flex gap-2 justify-content-lg-end">
                            <button type="submit" class="btn btn-success px-4">Cari</button>
                            <a href="komentar.php" class="btn btn-outline-secondary px-4">Reset</a>
                        </div>
                    </form>

                    <div class="table-responsive">
                        <table class="table table-kelola table-hover align-middle">
                    <thead>
                        <tr>
                            <th width="5%">No</th>
                            <th>Nama</th>
                            <th>Komentar</th>
                            <th>Berita</th>
                            <th>Tanggal</th>
                            <th width="12%">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($komentarList)): ?>
                            <?php $no = 1; ?>
                            <?php foreach ($komentarList as $k): ?>
                                <tr>
                                    <td class="text-muted"><?= $no++ ?></td>
                                    <td class="fw-semibold text-capitalize"><?= htmlspecialchars($k['nama'], ENT_QUOTES) ?></td>
                                    <td class="text-wrap" style="max-width: 320px;">
                                        <small class="text-muted">
                                            <?= htmlspecialchars(strlen($k['isi']) > 70 ? substr($k['isi'], 0, 70) . '...' : $k['isi'], ENT_QUOTES) ?>
                                        </small>
                                    </td>
                                    <td class="text-wrap" style="max-width: 200px;">
                                        <small class="text-muted">
                                            <?= htmlspecialchars(strlen($k['judul']) > 40 ? substr($k['judul'], 0, 40) . '...' : $k['judul'], ENT_QUOTES) ?>
                                        </small>
                                    </td>
                                    <td><small class="text-muted"><?= date('d M Y H:i', strtotime($k['tanggal'])) ?></small></td>
                                    <td>
                                        <a href="komentar.php?hapus_komentar=<?= intval($k['id']); ?>"
                                           onclick="return confirm('Hapus komentar ini?')"
                                           class="btn btn-outline-danger btn-sm">
                                           <i class="fa fa-trash"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="text-center text-muted py-5">
                                    <i class="fa fa-inbox fa-2x mb-2"></i><br>
                                    Tidak ada komentar yang ditemukan.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/dashboard.js"></script>
<script src="assets/js/komentar.js"></script>
</body>
</html>
<?php ob_end_flush(); ?>
