<?php
session_start();
require_once __DIR__ . '/../includes/config.php';

// Cek akses admin
if (!isset($_SESSION['user']) || ($_SESSION['role'] ?? '') !== 'admin') {
    header('Location: ../login.php');
    exit;
}

// Validasi parameter ID
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Location: dashboard.php?page=kelola');
    exit;
}

$id = (int) $_GET['id'];

// Ambil judul berita untuk aktivitas audit, jika ada
$stmt = $conn->prepare('SELECT judul FROM berita WHERE id = ?');
$stmt->bind_param('i', $id);
$stmt->execute();
$result = $stmt->get_result();
$news = $result->fetch_assoc();
$stmt->close();

if ($news) {
    $_SESSION['activity_delete'] = $news['judul'];

    $stmt = $conn->prepare('DELETE FROM berita WHERE id = ?');
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $stmt->close();
}

header('Location: dashboard.php?page=kelola');
exit;