function setTheme(mode){
    const body = document.body;
    body.classList.remove("dark");

    if(mode === "dark"){
        body.classList.add("dark");
    }
}

/* TOGGLE */
function toggleTheme(){
    let current = localStorage.getItem("theme");

    if(current === "dark"){
        localStorage.setItem("theme","light");
        setTheme("light");
    }else{
        localStorage.setItem("theme","dark");
        setTheme("dark");
    }
}

/* AUTO TIME */
function autoTheme(){
    const hour = new Date().getHours();
    return (hour >= 18 || hour < 6) ? "dark" : "light";
}

/* LOAD */
window.onload = function(){
    let saved = localStorage.getItem("theme");

    if(saved){
        setTheme(saved);
    }else{
        setTheme(autoTheme());
    }
}