<?php
session_start();
include __DIR__ . '/includes/config.php';

$keyword = $_GET['keyword'] ?? '';
$kategori = $_GET['kategori'] ?? '';
$kategoriNav = mysqli_query($conn, "
    SELECT DISTINCT kategori
    FROM berita
    WHERE kategori IS NOT NULL
      AND kategori != ''
    ORDER BY kategori ASC
");

header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

const UPLOAD_DIR = __DIR__ . '/uploads/';

function isAdmin(): bool
{
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

function sanitizePost(mysqli $conn, string $key): string
{
    return isset($_POST[$key])
        ? mysqli_real_escape_string($conn, trim($_POST[$key]))
        : '';
}

function uploadPhoto(string $fieldName): string
{
    if (empty($_FILES[$fieldName]['name'])) {
        return '';
    }

    $fileName = time() . '_' . basename($_FILES[$fieldName]['name']);
    $targetPath = UPLOAD_DIR . $fileName;

    if (is_uploaded_file($_FILES[$fieldName]['tmp_name'])) {
        move_uploaded_file($_FILES[$fieldName]['tmp_name'], $targetPath);
        return $fileName;
    }

    return '';
}

function redirect(string $query = ''): void
{
    header('Location: contact.php' . ($query ? "?{$query}" : ''));
    exit;
}
/* =========================
   KIRIM PESAN CONTACT
========================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['kirim'])) {

    $nama  = mysqli_real_escape_string($conn, trim($_POST['nama']));
    $email = mysqli_real_escape_string($conn, trim($_POST['email']));
    $pesan = mysqli_real_escape_string($conn, trim($_POST['pesan']));

    if ($nama && $email && $pesan) {
        mysqli_query($conn,
            "INSERT INTO contact_messages (nama, email, pesan)
             VALUES ('$nama', '$email', '$pesan')"
        );

        $success = "Pesan berhasil dikirim!";
    } else {
        $error = "Semua field wajib diisi!";
    }
}

/* =========================
   AMBIL PESAN (ADMIN ONLY)
========================= */
$messages = mysqli_query($conn, "SELECT * FROM contact_messages ORDER BY id DESC");
?>
<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Kontak</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        html, body {
            height: 100%;
        }
        .main-content {
            flex: 1;
        }
        body {
            padding-top: 110px;
            background: linear-gradient(to bottom, #f8fafc, #eef2f7);
            font-family: 'Segoe UI', sans-serif;

            display: flex;
            flex-direction: column;
        }

        /* ===== NAVBAR SAMA INDEX ===== */
        .navbar-top {
            background: rgba(255, 255, 255, 0.7);
            backdrop-filter: blur(15px);
            border-bottom: 1px solid rgba(255, 255, 255, 0.3);
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.05);
            z-index: 1055;
        }

        .navbar-menu {
            background: rgba(255, 255, 255, 0.6);
            backdrop-filter: blur(12px);
            border-bottom: 1px solid rgba(255, 255, 255, 0.3);
            z-index: 1040;
        }

        .navbar-brand {
            font-weight: 700;
            font-size: 20px;
            letter-spacing: 1px;
            background: linear-gradient(45deg, #0d6efd, #6610f2);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .brand-title {
    font-weight: 800;
    font-size: 20px;
    background: linear-gradient(45deg, #0d6efd, #6610f2);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}

.brand-subtitle {
    font-size: 11px;
    color: #6b7280;
}

.user-box {
    cursor: pointer;
    padding: 5px 10px;
    border-radius: 30px;
    transition: 0.3s;
}

.user-box:hover {
    background: rgba(0,0,0,0.05);
}



        .nav-link {
            position: relative;
            font-weight: 500;
            color: #333 !important;
            transition: 0.3s;
        }

        .nav-link::after {
            content: "";
            position: absolute;
            left: 0;
            bottom: -5px;
            width: 0%;
            height: 2px;
            background: #0d6efd;
            transition: 0.3s;
        }

        .nav-link:hover {
            color: #0d6efd !important;
        }

        .nav-link:hover::after {
            width: 100%;
        }

        .nav-link.active {
            color: #0d6efd !important;
            font-weight: 600;
        }

        .nav-link.active::after {
            width: 100%;
        }

        /* SEARCH */
        .search-box {
            max-width: 500px;
            width: 100%;
            position: relative;
        }

        .search-box input {
            padding-left: 40px;
            border-radius: 30px;
            border: none;
            background: #f1f5f9;
        }

        .search-box i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
        }

        /* AVATAR */
        .avatar {
            width: 38px;
            height: 38px;
            border-radius: 50%;
            border: 2px solid #0d6efd;
        }

        /* ===== STYLE ASLI TIDAK DIUBAH ===== */
        .card-box {
            background: white;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        .foto {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            object-fit: cover;
        }
        html {
            overflow-y: scroll;
        }
        .btn-search {
    border-radius: 30px;
    height: 46px;
    background: linear-gradient(45deg, #0d6efd, #6610f2);
    color: white;
    border: none;
    font-weight: 600;
    padding: 0 22px;
    transition: 0.3s;
    white-space: nowrap;
}

.btn-search:hover {
    transform: translateY(-1px);
    box-shadow: 0 6px 18px rgba(13, 110, 253, 0.3);
}
html, body {
    height: 100%;
}

body {
    display: flex;
    flex-direction: column;
}

.main-content {
    flex: 1;
}
    </style>
</head>

<body>
    <!-- ================= NAVBAR ATAS ================= -->
    <nav class="navbar navbar-top fixed-top py-2">
    <div class="container d-flex align-items-center justify-content-between">

        <!-- BRAND -->
        <a class="navbar-brand d-flex flex-column" href="index.php">
            <span class="brand-title">
                ⚡ Kabar<span class="text-primary">Nusantara</span>
            </span>
            <small class="brand-subtitle">Berita Cepat & Terpercaya</small>
        </a>

        <!-- SEARCH TETAP PUNYA KAMU -->
          <form class="search-box d-flex align-items-center position-relative mx-auto"
      method="GET" action="index.php">

    <i class="bi bi-search"></i>

    <input type="text"
           name="keyword"
           class="form-control"
           placeholder="Cari berita viral hari ini..."
           value="<?= htmlspecialchars($keyword ?? '', ENT_QUOTES); ?>">

    <?php if($kategori != ''): ?>
        <input type="hidden" name="kategori" value="<?= htmlspecialchars($kategori) ?>">
    <?php endif; ?>

    <button class="btn btn-search ms-2 px-4" type="submit">
        Cari
    </button>
</form>
        <!-- USER AREA -->
        <div class="d-flex align-items-center gap-3">

            <?php if (isset($_SESSION['user']) && isAdmin()): ?>
                <a href="admin/dashboard.php" class="btn btn-warning btn-sm fw-semibold shadow-sm">
                    <i class="bi bi-speedometer2"></i> Dashboard
                </a>
            <?php endif; ?>

            <?php if (isset($_SESSION['user'])): ?>
                <div class="dropdown">
                    <a href="#" data-bs-toggle="dropdown" class="d-flex align-items-center gap-2 user-box">
                        <img src="https://ui-avatars.com/api/?name=<?= urlencode($_SESSION['user']); ?>&background=0D6EFD&color=fff&bold=true"
     class="avatar"
     alt="Avatar">
                        <span class="d-none d-md-block fw-semibold"><?= htmlspecialchars($_SESSION['user'], ENT_QUOTES); ?></span>
                        <i class="bi bi-chevron-down small"></i>
                    </a>

                    <ul class="dropdown-menu dropdown-menu-end shadow border-0 mt-2">
                        <li class="dropdown-item fw-semibold"><?= htmlspecialchars($_SESSION['user'], ENT_QUOTES); ?></li>
                        <li><hr></li>
                        <li>
                            <a class="dropdown-item text-danger" href="logout.php">
                                <i class="bi bi-box-arrow-right me-1"></i> Logout
                            </a>
                        </li>
                    </ul>
                </div>
            <?php else: ?>
                <a href="login.php" class="btn btn-primary btn-sm px-3 shadow-sm">
                    <i class="bi bi-person"></i> Login
                </a>
            <?php endif; ?>

        </div>
    </div>
</nav>
<!-- NAVBAR MENU (UPGRADE) -->
<nav class="navbar navbar-menu fixed-top" style="top:65px;">
    <div class="container">
        <div class="d-flex justify-content-center w-100">
            <ul class="navbar-nav flex-row gap-4 flex-wrap align-items-center">

                <!-- HOME -->
                <li class="nav-item">
                    <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'index.php' && $kategori == '' ? 'active' : '' ?>"
                       href="index.php">
                        <i class="bi bi-house-door me-1"></i> Home
                    </a>
                </li>

                <!-- KATEGORI -->
                <?php if ($kategoriNav): ?>
                    <?php while($kat = mysqli_fetch_assoc($kategoriNav)): ?>
                        <li class="nav-item">
                            <a class="nav-link <?= $kategori == $kat['kategori'] ? 'active' : '' ?>"
                               href="index.php?kategori=<?= urlencode($kat['kategori']) ?>">
                                <i class="bi bi-grid me-1"></i>
                                <?= htmlspecialchars($kat['kategori']) ?>
                            </a>
                        </li>
                    <?php endwhile; ?>
                <?php endif; ?>

                <!-- ABOUT -->
                <li class="nav-item">
                    <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'about.php' ? 'active' : '' ?>"
                       href="about.php">
                        <i class="bi bi-info-circle me-1"></i> About
                    </a>
                </li>

                <!-- CONTACT -->
                <li class="nav-item">
                    <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'contact.php' ? 'active' : '' ?>"
                       href="contact.php">
                        <i class="bi bi-envelope me-1"></i> Contact
                    </a>
                </li>

            </ul>
        </div>
    </div>
</nav>

    <div class="container mt-5 mb-5 main-content">
    <div class="row justify-content-center">
        <div class="col-md-6">

            <div class="card-box text-start">
                <h3 class="mb-3">📩 Contact Kami</h3>

                <?php if (!empty($success)): ?>
                    <div class="alert alert-success"><?= $success ?></div>
                <?php endif; ?>

                <?php if (!empty($error)): ?>
                    <div class="alert alert-danger"><?= $error ?></div>
                <?php endif; ?>

                <form method="POST">
                    <input type="text" name="nama" class="form-control mb-2" placeholder="Nama Anda">
                    <input type="email" name="email" class="form-control mb-2" placeholder="Email Anda">
                    <textarea name="pesan" class="form-control mb-3" rows="5" placeholder="Tulis pesan..."></textarea>

                    <button name="kirim" class="btn btn-primary w-100">
                        Kirim Pesan
                    </button>
                </form>
            </div>

        </div>
    </div>

</div>
    <footer style="background:#fff;border-top:1px solid #ddd; margin-top:auto;">
        <div class="container text-center py-4">
            <small class="text-muted">© <?= date('Y'); ?> Kabar Nusantara</small>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>