<?php
session_start();
require_once __DIR__ . "/includes/config.php";

/* =========================
   VALIDASI ID
========================= */
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($id <= 0) {
    echo "ID tidak valid";
    exit;
}

/* =========================
   AMBIL BERITA
========================= */
$stmt = $conn->prepare("SELECT * FROM berita WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$berita = $result->fetch_assoc();

if (!$berita) {
    echo "Berita tidak ditemukan";
    exit;
}

/* =========================
   HAPUS KOMENTAR (ADMIN)
========================= */
if (isset($_GET['hapus']) && ($_SESSION['role'] ?? '') === 'admin') {
    $hapus_id = intval($_GET['hapus']);

    if ($hapus_id > 0) {
        $stmt = $conn->prepare("DELETE FROM komentar WHERE id = ?");
        $stmt->bind_param("i", $hapus_id);
        $stmt->execute();
    }

    header("Location: detail.php?id=$id&msg=hapus");
    exit;
}

/* =========================
   SIMPAN KOMENTAR
========================= */
if (isset($_POST['kirim_komentar']) && isset($_SESSION['user'])) {
    $nama = htmlspecialchars($_SESSION['user']);
    $isi  = trim($_POST['isi']);

    if (!empty($isi)) {
        $stmt = $conn->prepare("INSERT INTO komentar (berita_id, nama, isi) VALUES (?, ?, ?)");
        $stmt->bind_param("iss", $id, $nama, $isi);
        $stmt->execute();
    }

    header("Location: detail.php?id=$id&msg=sukses");
    exit;
}

/* =========================
   AMBIL KOMENTAR
========================= */
$stmt = $conn->prepare("SELECT * FROM komentar WHERE berita_id = ? ORDER BY id DESC");
$stmt->bind_param("i", $id);
$stmt->execute();
$komentar = $stmt->get_result();
$totalKomentar = $komentar->num_rows;
?>

<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?= htmlspecialchars($berita['judul']); ?></title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background: #eef2f7;
            font-family: 'Segoe UI', sans-serif;
        }
        .container {
            max-width: 800px;
        }
        .title {
            font-size: 32px;
            font-weight: 700;
        }
        .meta {
            color: #999;
            font-size: 14px;
        }
        .hero-img {
            width: 100%;
            max-height: 420px;
            object-fit: cover;
            border-radius: 12px;
            margin: 20px 0;
        }
        .content {
            font-size: 18px;
            line-height: 1.8;
        }
        .comment-box {
            background: #fff;
            border-radius: 12px;
            padding: 15px;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.05);
        }
        .comment-item {
            border-bottom: 1px solid #eee;
            padding: 12px 0;
        }
        .comment-item:last-child {
            border-bottom: none;
        }
        .btn-dark {
            border-radius: 20px;
            padding: 6px 18px;
        }
        .badge-count {
            background: #333;
        }
        .news-badge {
            background: linear-gradient(45deg, #0d6efd, #6610f2);
            color: white;
            padding: 8px 18px;
            border-radius: 50px;
            font-size: 13px;
            font-weight: 600;
        }
    </style>
</head>

<body>
    <div class="container mt-5 mb-5">
        <a href="index.php" class="text-decoration-none text-muted">← Kembali</a>

        <hr>

        <h1 class="title"><?= htmlspecialchars($berita['judul']); ?></h1>

        <div class="meta mb-3">
            <?= date('d M Y', strtotime($berita['tanggal'] ?? date('Y-m-d'))); ?>
        </div>
        <?php if (!empty($berita['kategori'])): ?>
            <?php
                $kat = strtolower($berita['kategori']);
                $warna = 'bg-secondary';

                if (strpos($kat, 'politik') !== false) {
                    $warna = 'bg-danger';
                } elseif (strpos($kat, 'olahraga') !== false) {
                    $warna = 'bg-success';
                } elseif (strpos($kat, 'teknologi') !== false) {
                    $warna = 'bg-info';
                } elseif (strpos($kat, 'pendidikan') !== false) {
                    $warna = 'bg-warning text-dark';
                } elseif (strpos($kat, 'hiburan') !== false) {
                    $warna = 'bg-dark';
                }
            ?>

            <div class="mb-3">
                <span class="badge <?= $warna ?> px-3 py-2 rounded-pill">
                    <?= htmlspecialchars($berita['kategori']); ?>
                </span>
            </div>
        <?php endif; ?>

        <?php if (!empty($berita['gambar']) && file_exists("uploads/" . $berita['gambar'])): ?>

            <img src="uploads/<?= htmlspecialchars($berita['gambar']); ?>" class="hero-img">
        <?php endif; ?>

        <div class="content mb-4">
            <?= nl2br(htmlspecialchars($berita['isi'])); ?>
        </div>

        <hr>

        <!-- NOTIFIKASI -->
        <?php if (isset($_GET['msg'])): ?>
            <div class="alert <?= $_GET['msg'] == 'sukses' ? 'alert-success' : 'alert-danger'; ?>">
                <?= $_GET['msg'] == 'sukses' ? 'Komentar berhasil dikirim' : 'Komentar dihapus'; ?>
            </div>
        <?php endif; ?>

        <h5 class="mb-3">
            💬 Komentar
            <span class="badge badge-count"><?= $totalKomentar; ?></span>
        </h5>

        <div class="comment-box mb-4">
            <?php if (isset($_SESSION['user'])): ?>
                <form method="POST">
                    <input type="text" class="form-control mb-2"
                           value="<?= htmlspecialchars($_SESSION['user']); ?>" readonly>

                    <textarea name="isi" class="form-control mb-2" rows="3"
                              placeholder="Tulis komentar..." required></textarea>

                    <button type="submit" name="kirim_komentar" class="btn btn-dark btn-sm">
                        Kirim
                    </button>
                </form>
            <?php else: ?>
                <div class="alert alert-warning mb-0">
                    Silakan <a href="login.php">login</a> untuk memberikan komentar.
                </div>
            <?php endif; ?>
        </div>

        <!-- LIST KOMENTAR -->
        <?php if ($totalKomentar > 0): ?>
            <?php while ($k = $komentar->fetch_assoc()): ?>
                <div class="comment-item">
                    <strong><?= htmlspecialchars($k['nama']); ?></strong>

                    <?php if (($_SESSION['role'] ?? '') === 'admin'): ?>
                        <a href="?id=<?= $id ?>&hapus=<?= $k['id']; ?>"
                           class="text-danger ms-2"
                           onclick="return confirm('Hapus komentar?')">
                           Hapus
                        </a>
                    <?php endif; ?>

                    <br>

                    <small class="text-muted">
                        <?= date('d M Y H:i', strtotime($k['tanggal'])); ?>
                    </small>

                    <p class="mb-0 mt-2">
                        <?= nl2br(htmlspecialchars($k['isi'])); ?>
                    </p>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="text-center text-muted py-4">
                💬 Belum ada komentar, jadi yang pertama ya!
            </div>
        <?php endif; ?>

        <hr>

        <small class="text-muted">© <?= date('Y'); ?> Kabar Nusantara</small>
    </div>
</body>
</html>