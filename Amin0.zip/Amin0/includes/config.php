<?php
$conn = mysqli_connect("localhost", "root", "", "amin0");
if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>
