<?php
ob_start();
session_start();
include __DIR__ . "/includes/config.php";

/* =========================
   NEWSLETTER SUBMIT
========================= */
if (isset($_POST['email'])) {
    $email = trim($_POST['email']);

    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $stmt = $conn->prepare("INSERT INTO newsletter (email) VALUES (?)");
        $stmt->bind_param("s", $email);
        $stmt->execute();
    }
}

/* =========================
   SEARCH
========================= */
$keyword = $_GET['keyword'] ?? '';
$kategori = $_GET['kategori'] ?? '';

// ambil kategori untuk navbar
$kategoriNav = mysqli_query($conn, "
    SELECT DISTINCT kategori 
    FROM berita 
    WHERE kategori IS NOT NULL 
    AND kategori != ''
    ORDER BY kategori ASC
");

/* =========================
   QUERY BERITA (SEARCH + KATEGORI)
========================= */
if ($keyword != '' && $kategori != '') {

    // SEARCH + KATEGORI
    $stmt = $conn->prepare("
        SELECT * FROM berita 
        WHERE (judul LIKE ? OR isi LIKE ?) 
        AND kategori = ?
        ORDER BY id DESC
    ");
    $search = "%$keyword%";
    $stmt->bind_param("sss", $search, $search, $kategori);
    $stmt->execute();
    $query = $stmt->get_result();

} elseif ($keyword != '') {

    // SEARCH SAJA
    $stmt = $conn->prepare("
        SELECT * FROM berita 
        WHERE judul LIKE ? OR isi LIKE ?
        ORDER BY id DESC
    ");
    $search = "%$keyword%";
    $stmt->bind_param("ss", $search, $search);
    $stmt->execute();
    $query = $stmt->get_result();

} elseif ($kategori != '') {

    // KATEGORI SAJA
    $stmt = $conn->prepare("
        SELECT * FROM berita 
        WHERE kategori = ?
        ORDER BY id DESC
    ");
    $stmt->bind_param("s", $kategori);
    $stmt->execute();
    $query = $stmt->get_result();

} else {

    // SEMUA
    $query = mysqli_query($conn, "
    SELECT * FROM berita 
    ORDER BY id DESC 
    LIMIT 10
");
}

/* =========================
   SLIDER
========================= */
$slider = mysqli_query($conn, "SELECT * FROM berita ORDER BY id DESC LIMIT 3");
?>

<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Website Saya</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        html {
            overflow-y: scroll;
        }

        body {
            padding-top: 110px;
            background: linear-gradient(to bottom, #f8fafc, #eef2f7);
            font-family: 'Segoe UI', sans-serif;
            overflow-x: hidden;
        }

        .navbar-top {
            background: rgba(255, 255, 255, 0.75);
            backdrop-filter: blur(15px);
            border-bottom: 1px solid rgba(255, 255, 255, 0.3);
            box-shadow: 0 5px 25px rgba(0, 0, 0, 0.08);
            z-index: 1055;
        }

        .navbar-menu {
            background: rgba(255, 255, 255, 0.65);
            backdrop-filter: blur(12px);
            border-top: 1px solid rgba(255, 255, 255, 0.3);
            z-index: 1040;
        }

        .navbar-brand,
        .brand-title {
            font-weight: 800;
            font-size: 20px;
            letter-spacing: 1px;
            background: linear-gradient(45deg, #0d6efd, #6610f2);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .brand-subtitle {
            font-size: 11px;
            color: #6b7280;
        }

        .search-box {
            max-width: 500px;
            width: 100%;
            position: relative;
        }

        .search-box input {
            padding-left: 40px;
            border-radius: 30px;
            border: none;
            background: #f1f5f9;
            box-shadow: inset 0 2px 5px rgba(0, 0, 0, 0.05);
            transition: 0.3s;
        }

        .search-box input:focus {
            background: #fff;
            box-shadow: 0 0 0 3px rgba(13, 110, 253, 0.2);
        }

        .search-box i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #888;
        }

        .user-box {
            cursor: pointer;
            padding: 5px 10px;
            border-radius: 30px;
            transition: 0.3s;
        }

        .user-box:hover {
            background: rgba(0, 0, 0, 0.05);
        }

        .nav-link {
            position: relative;
            font-weight: 500;
            color: #333 !important;
            transition: 0.3s;
        }

        .nav-link::after {
            content: "";
            position: absolute;
            left: 0;
            bottom: -5px;
            width: 0;
            height: 2px;
            background: #0d6efd;
            transition: 0.3s;
        }

        .nav-link:hover,
        .nav-link.active {
            color: #0d6efd !important;
        }

        .nav-link:hover::after,
        .nav-link.active::after {
            width: 100%;
        }

        .avatar {
            width: 38px;
            height: 38px;
            border-radius: 50%;
            border: 2px solid #0d6efd;
        }

        .card:hover {
            transform: translateY(-5px);
            transition: 0.3s;
            box-shadow: 0 12px 25px rgba(0, 0, 0, 0.15);
        }

        .hero-slider-wrapper {
            max-width: 1180px;
            margin: 0 auto;
            padding: 0 15px;
        }

        .hero-slider,
        .carousel-item img {
            width: 100%;
            height: 460px;
            object-fit: cover;
            display: block;
        }

        .hero-slider {
            position: relative;
            border-radius: 18px;
            overflow: hidden;
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.15);
        }

        .hero-overlay {
            position: absolute;
            inset: 0;
            background: linear-gradient(to top, rgba(0, 0, 0, 0.8), rgba(0, 0, 0, 0.2));
        }

        .hero-content {
            position: absolute;
            bottom: 40px;
            left: 40px;
            right: 40px;
            color: #fff;
            z-index: 2;
        }

        .hero-content h2 {
            font-size: 32px;
            font-weight: 700;
        }

        .hero-content p {
            color: #ddd;
            max-width: 600px;
        }

        .hero-card {
            max-width: 600px;
            backdrop-filter: blur(12px);
            background: rgba(255, 255, 255, 0.1);
            border-radius: 16px;
            padding: 20px;
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .newsletter {
            margin-top: 60px;
            margin-bottom: 40px;
            padding: 40px;
            border-radius: 16px;
            background: linear-gradient(135deg, #3b82f6, #2563eb);
            color: white;
            transition: 0.3s;
        }

        .newsletter:hover,
        .newsletter-box:hover {
            transform: translateY(-3px);
            box-shadow: 0 20px 50px rgba(0, 0, 0, 0.2);
        }

        .newsletter input,
        .newsletter-form input {
            border-radius: 30px;
            border: none;
            padding: 12px 20px;
        }

        .newsletter button,
        .newsletter-form button {
            border-radius: 30px;
            padding: 10px 20px;
            border: none;
            transition: 0.3s;
        }

        .newsletter-form button {
            background: white;
            color: #2563eb;
            font-weight: 600;
        }

        .newsletter-form button:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
        }

        h2 {
            border-left: 5px solid #0d6efd;
            padding-left: 10px;
        }

        .text-center i {
            transition: 0.3s;
        }

        .text-center:hover i {
            transform: scale(1.2);
        }

        .badge-trending {
            background: linear-gradient(135deg, rgba(13, 110, 253, 0.1), rgba(102, 16, 242, 0.1));
            color: #0d6efd;
            padding: 6px 14px;
            border-radius: 30px;
            text-decoration: none;
            font-size: 13px;
            font-weight: 500;
            transition: 0.3s;
            border: 1px solid rgba(13, 110, 253, 0.15);
            white-space: nowrap;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        .badge-trending:hover {
            background: linear-gradient(45deg, #0d6efd, #6610f2);
            color: #fff;
            transform: translateY(-2px) scale(1.05);
            box-shadow: 0 5px 15px rgba(13, 110, 253, 0.3);
        }

        .active-trending {
            background: linear-gradient(45deg, #0d6efd, #6610f2);
            color: #fff !important;
            font-weight: 600;
        }

        .trending-divider {
            height: 1px;
            background: #e5e7eb;
            margin: 20px 0 30px;
        }

        .trending-row {
            overflow-x: auto;
            flex-wrap: nowrap;
            padding-bottom: 10px;
            scrollbar-width: none;
        }

        .trending-row::-webkit-scrollbar {
            display: none;
        }

        .trend-count {
            background: rgba(255, 255, 255, 0.25);
            padding: 2px 8px;
            border-radius: 20px;
            font-size: 11px;
        }

        .newsletter-box {
            padding: 40px;
            border-radius: 20px;
            background: linear-gradient(135deg, #3b82f6, #2563eb);
            color: white;
            position: relative;
            overflow: hidden;
            box-shadow: 0 20px 50px rgba(37, 99, 235, 0.25);
        }

        .content-box {
            width: 100%;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
            background: #fff;
        }

        .carousel-item {
            transition: transform 1s ease;
        }

        .btn-search {
            border-radius: 30px;
            height: 46px;
            background: linear-gradient(45deg, #0d6efd, #6610f2);
            color: white;
            border: none;
            font-weight: 600;
            padding: 0 22px;
            transition: 0.3s;
            white-space: nowrap;
        }

        .btn-search:hover {
            transform: translateY(-1px);
            box-shadow: 0 6px 18px rgba(13, 110, 253, 0.3);
        }

        @media (max-width: 768px) {
            .newsletter-form {
                width: 100%;
            }

            .newsletter-form input {
                flex: 1;
                width: 100%;
            }
        }
    </style>
</head>

<body>
   <!-- NAVBAR TOP (UPGRADE) -->
<nav class="navbar navbar-top fixed-top py-2">
    <div class="container d-flex align-items-center justify-content-between">

        <!-- BRAND -->
        <a class="navbar-brand d-flex flex-column" href="index.php">
            <span class="brand-title">
                ⚡ Kabar<span class="text-primary">Nusantara</span>
            </span>
            <small class="brand-subtitle">Berita Cepat & Terpercaya</small>
        </a>

        
    
<!-- SEARCH UPGRADE BUTTON TEXT -->
<form class="search-box d-flex align-items-center position-relative mx-auto"
      method="GET" action="index.php">

    <i class="bi bi-search"></i>

    <input type="text"
           name="keyword"
           class="form-control"
           placeholder="Cari berita viral hari ini..."
           value="<?= htmlspecialchars($keyword ?? '', ENT_QUOTES); ?>">

    <?php if($kategori != ''): ?>
        <input type="hidden" name="kategori" value="<?= htmlspecialchars($kategori) ?>">
    <?php endif; ?>

    <button class="btn btn-search ms-2 px-4" type="submit">
        Cari
    </button>
</form>

        <!-- USER AREA -->
        <div class="d-flex align-items-center gap-3">

            <!-- ADMIN -->
            <?php if (isset($_SESSION['user']) && $_SESSION['role'] == 'admin'): ?>
                <a href="admin/dashboard.php" class="btn btn-warning btn-sm fw-semibold shadow-sm">
                    <i class="bi bi-speedometer2"></i> Dashboard
                </a>
            <?php endif; ?>

            <!-- USER LOGIN -->
            <?php if (isset($_SESSION['user'])): ?>
                <div class="dropdown">
                    <a data-bs-toggle="dropdown" class="d-flex align-items-center gap-2 user-box">
                        <img src="https://ui-avatars.com/api/?name=<?= urlencode($_SESSION['user']); ?>&background=0D6EFD&color=fff&bold=true"
                                class="avatar"
                                alt="Avatar">
                        <span class="d-none d-md-block fw-semibold"><?= htmlspecialchars($_SESSION['user']); ?></span>
                        <i class="bi bi-chevron-down small"></i>
                    </a>

                    <ul class="dropdown-menu dropdown-menu-end shadow border-0 mt-2">
                        <li class="dropdown-item fw-semibold"><?= htmlspecialchars($_SESSION['user']); ?></li>
                        <li><hr></li>
                        <li>
                            <a class="dropdown-item text-danger" href="logout.php">
                                <i class="bi bi-box-arrow-right me-1"></i> Logout
                            </a>
                        </li>
                    </ul>
                </div>
            <?php else: ?>
                <a href="login.php" class="btn btn-primary btn-sm px-3 shadow-sm">
                    <i class="bi bi-person"></i> Login
                </a>
            <?php endif; ?>

        </div>
    </div>
</nav>

<!-- NAVBAR MENU (UPGRADE) -->
<nav class="navbar navbar-menu fixed-top" style="top:65px;">
    <div class="container">
        <div class="d-flex justify-content-center w-100">
            <ul class="navbar-nav flex-row gap-4 flex-wrap align-items-center">

                <!-- HOME -->
                <li class="nav-item">
                    <a class="nav-link <?= ($kategori == '' && basename($_SERVER['PHP_SELF']) == 'index.php') ? 'active' : '' ?>" href="index.php">
                        <i class="bi bi-house-door me-1"></i> Home
                    </a>
                </li>

                <!-- KATEGORI -->
                <?php while($kat = mysqli_fetch_assoc($kategoriNav)): ?>
                    <li class="nav-item">
                        <a class="nav-link <?= $kategori == $kat['kategori'] ? 'active' : '' ?>"
                           href="index.php?kategori=<?= urlencode($kat['kategori']) ?>">
                            <i class="bi bi-grid me-1"></i>
                            <?= htmlspecialchars($kat['kategori']) ?>
                        </a>
                    </li>
                <?php endwhile; ?>

                <!-- ABOUT -->
                <li class="nav-item">
                    <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'about.php' ? 'active' : '' ?>" href="about.php">
                        <i class="bi bi-info-circle me-1"></i> About
                    </a>
                </li>

                <!-- CONTACT -->
                <li class="nav-item">
                    <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'contact.php' ? 'active' : '' ?>" href="contact.php">
                        <i class="bi bi-envelope me-1"></i> Contact
                    </a>
                </li>

            </ul>
        </div>
    </div>
</nav>

    
    <!-- HERO SLIDER -->
    <div class="container-fluid mt-4 px-0">
        <div class="hero-slider-wrapper">
            <div id="newsCarousel" class="carousel slide hero-slider"
                 data-bs-ride="carousel"
                 data-bs-interval="1000"
                 data-bs-touch="true"
                 data-bs-pause="hover">

                <div class="carousel-inner">
                <?php if ($slider && mysqli_num_rows($slider) > 0): ?>
                    <?php $no = 0; while ($s = mysqli_fetch_assoc($slider)): ?>
                        <div class="carousel-item <?= $no == 0 ? 'active' : ''; ?>">
                            <?php if (!empty($s['gambar'])): ?>
    <img src="uploads/<?= htmlspecialchars($s['gambar']); ?>" 
         class="d-block w-100"
         loading="eager"
         fetchpriority="high"
         decoding="async">
<?php endif; ?>

                            <div class="hero-overlay"></div>

                            <div class="hero-content">
                                <div class="hero-card">
                                    <h2><?= htmlspecialchars($s['judul']); ?></h2>
                                    <p><?= htmlspecialchars(substr(strip_tags($s['isi']), 0, 120)); ?>...</p>

                                    <a href="detail.php?id=<?= $s['id']; ?>"
                                       class="text-white text-decoration-none fw-semibold">
                                        Baca →
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php $no++; endwhile; ?>
                <?php else: ?>
                    <div class="alert alert-warning text-center">
                        Slider tidak tersedia
                    </div>
                <?php endif; ?>
            </div>

            <button class="carousel-control-prev" type="button" data-bs-target="#newsCarousel" data-bs-slide="prev">
                <span class="carousel-control-prev-icon"></span>
            </button>

            <button class="carousel-control-next" type="button" data-bs-target="#newsCarousel" data-bs-slide="next">
                <span class="carousel-control-next-icon"></span>
            </button>
        </div>
    </div>

    <!-- CONTENT -->
    <?php if (isset($_GET['subscribe'])): ?>
        <div class="container mt-4">
            <div class="alert alert-success text-center">
                ✅ Email berhasil didaftarkan!
            </div>
        </div>
    <?php endif; ?>



<!-- TRENDING MODERN -->
<div class="container-fluid mt-5 px-0 content-box">
    <div class="hero-slider-wrapper py-4">

        <!-- TRENDING -->
  <div class="trending-box mb-4">
    <div class="d-flex align-items-center justify-content-between flex-wrap gap-3">
        
            
     
    <div class="d-flex flex-wrap align-items-center gap-2 trending-row mt-3">
    <span class="fw-semibold text-dark me-2 fs-5">
    <i class="bi bi-fire text-danger"></i> Topik Populer Hari Ini
</span>
   </div>

        <small class="text-muted">
            Update terbaru • <?= date('d M Y') ?>
        </small>
    </div>

<?php
$trendingQuery = mysqli_query($conn, "
    SELECT 
        k.nama_kategori,
        COUNT(b.id) as total
    FROM kategori k
    LEFT JOIN berita b ON b.kategori = k.nama_kategori
    GROUP BY k.nama_kategori
    ORDER BY total DESC
    LIMIT 6
");
while($trend = mysqli_fetch_assoc($trendingQuery)):
    $t = $trend['nama_kategori'];
    $jumlah = $trend['total'];

    // icon otomatis
    $icon = 'bi-tag';

    if (stripos($t, 'ekonomi') !== false) $icon = 'bi-graph-up-arrow';
    elseif (stripos($t, 'olahraga') !== false) $icon = 'bi-trophy';
    elseif (stripos($t, 'teknologi') !== false) $icon = 'bi-cpu';
    elseif (stripos($t, 'politik') !== false) $icon = 'bi-bank';
    elseif (stripos($t, 'kesehatan') !== false) $icon = 'bi-heart-pulse';
    elseif (stripos($t, 'pendidikan') !== false) $icon = 'bi-book';
?>
    <a href="index.php?kategori=<?= urlencode($t); ?>" 
       class="badge-trending <?= $kategori == $t ? 'active-trending' : '' ?>">
        <i class="bi <?= $icon ?> me-1"></i>
        <?= htmlspecialchars($t); ?>
        <span class="trend-count"><?= $jumlah ?></span>
    </a>
<?php endwhile; ?>


</div>

        <!-- JUDUL -->
        <h2 class="mt-4" style="font-family:'Playfair Display',serif; font-weight:900;">
            <?php if($kategori != ''): ?>
                <?= htmlspecialchars($kategori) ?>
            <?php elseif($keyword != ''): ?>
                Pencarian: <?= htmlspecialchars($keyword) ?>
            <?php else: ?>
                Berita Terbaru
            <?php endif; ?>
        </h2>

        <!-- DESKRIPSI -->
        <p class="text-muted mb-4">
            <?php if($kategori != ''): ?>
                Kumpulan berita terbaru seputar <?= strtolower(htmlspecialchars($kategori)) ?>.
            <?php elseif($keyword != ''): ?>
                Menampilkan hasil pencarian untuk "<b><?= htmlspecialchars($keyword) ?></b>".
            <?php else: ?>
                Informasi terbaru dan terpercaya dari berbagai topik pilihan.
            <?php endif; ?>
        </p>

        <!-- LIST BERITA -->
        <div class="row g-4">

<?php if ($query && mysqli_num_rows($query) == 0) { ?>

    <div class="col-12">
        <div class="text-center py-5">
            <i class="bi bi-search" style="font-size:50px; color:#cbd5e1;"></i>

            <h5 class="mt-3 fw-semibold">Tidak ada hasil</h5>

            <p class="text-muted mb-3">
                Tidak ditemukan berita yang sesuai dengan pencarian Anda.
            </p>

            <a href="index.php" class="btn btn-outline-primary btn-sm">
                Kembali ke Beranda
            </a>
        </div>
    </div>

<?php } else { ?>

<?php 
$i = 0;
while ($row = mysqli_fetch_assoc($query)) { 
?>

    <?php if ($i == 0) { ?>
        <div class="col-lg-8">
            <div class="card border-0 shadow-sm">

                <?php if (!empty($row['gambar'])) { ?>
    <img src="uploads/<?= htmlspecialchars($row['gambar']); ?>"
         loading="lazy"
         decoding="async"
         style="height:350px; width:100%; object-fit:cover;">
<?php } ?>

                <div class="card-body">
                    <h4><?= htmlspecialchars($row['judul']); ?></h4>
                    <p class="text-muted">
                        <?= htmlspecialchars(substr(strip_tags($row['isi']), 0, 200)); ?>...
                    </p>
                    <a href="detail.php?id=<?= $row['id']; ?>" class="btn btn-primary">
                        Baca Selengkapnya
                    </a>
                </div>
            </div>
        </div>

        <div class="col-lg-4 d-flex flex-column gap-3">

    <?php } else { ?>

        <div class="d-flex gap-3 p-2 rounded shadow-sm bg-white">
            <?php if (!empty($row['gambar']) && file_exists("uploads/" . $row['gambar'])) { ?>
                <img src="uploads/<?= htmlspecialchars($row['gambar']); ?>"
                     loading="lazy"
                     decoding="async"
                     style="width:100px; height:70px; object-fit:cover; border-radius:8px;">
            <?php } ?>

            <div>
                <h6 style="font-size:14px; font-weight:600;">
                    <?= htmlspecialchars($row['judul']); ?>
                </h6>
                <a href="detail.php?id=<?= $row['id']; ?>" class="text-primary small">
                   Baca →
                </a>
            </div>
        </div>

    <?php } ?>

<?php 
$i++;
} 
?>

</div> <!-- tutup sidebar -->

<?php } ?>

</div> <!-- row -->

<!-- NEWSLETTER MENYATU -->

<div class="newsletter-box mt-5 mb-5">
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-center gap-4">

        <div>
            <h3 class="fw-bold mb-1">
                <i class="bi bi-envelope-paper me-2"></i>
                Dapatkan Berita Terkini
            </h3>
            <p class="mb-0 text-muted">
                Daftar newsletter untuk update berita terbaru langsung ke email Anda.
            </p>
        </div>

        <form class="newsletter-form d-flex gap-2" method="POST">
            <input type="email" name="email" placeholder="Alamat email Anda..." required>
            <button>Daftar</button>
        </form>
    </div>
</div>

</div> <!-- box putih -->
</div> <!-- container -->




    <footer class="bg-white border-top">
        <div class="container text-center py-4">
            <small class="text-muted">© <?= date('Y'); ?> Kabar Nusantara</small>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php ob_end_flush(); ?>