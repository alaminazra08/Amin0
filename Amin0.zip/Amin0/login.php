<?php
session_start();
include 'includes/config.php';

if (isset($_POST['login'])) {
    $user = $_POST['username'];
    $pass = md5($_POST['password']);

    $cek = mysqli_query($conn, "SELECT * FROM users WHERE username='$user' AND password='$pass'");
    $data = mysqli_fetch_assoc($cek);

    if ($data) {
        $_SESSION['user'] = $data['username'];
        $_SESSION['role'] = strtolower($data['role']);

        if ($_SESSION['role'] == 'admin') {
            header("Location: admin/dashboard.php");
        } else {
            header("Location: index.php");
        }
        exit;
    } else {
        $error = "Username atau password salah";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Login</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', 'Segoe UI', sans-serif;
        }

        body {
            height: 100vh;
            display: flex;
            background: radial-gradient(circle at top, #0f172a, #020617);
            overflow: hidden;
        }

        /* BACKGROUND */
        body::before, body::after {
            content: '';
            position: absolute;
            border-radius: 50%;
            filter: blur(120px);
        }

        body::before {
            width: 600px;
            height: 600px;
            background: #4f46e5;
            top: -150px;
            left: -150px;
            opacity: .25;
        }

        body::after {
            width: 500px;
            height: 500px;
            background: #22d3ee;
            bottom: -150px;
            right: -150px;
            opacity: .2;
        }

        /* LEFT */
        .left {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            color: white;
        }

        .left h1 {
            font-size: 50px;
            font-weight: 900;
            letter-spacing: 1px;
            background: linear-gradient(to right, #22d3ee, #4f46e5);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        /* RIGHT */
        .right {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        /* CARD */
        .card-login {
            width: 100%;
            max-width: 420px;
            padding: 45px;
            border-radius: 26px;
            background: linear-gradient(145deg, rgba(255, 255, 255, 0.05), rgba(255, 255, 255, 0.02));
            backdrop-filter: blur(25px);
            border: 1px solid rgba(255, 255, 255, 0.08);
            box-shadow:
                0 10px 40px rgba(0, 0, 0, 0.7),
                inset 0 0 20px rgba(255, 255, 255, 0.03);
            color: white;
            animation: fadeUp .6s ease;
        }

        /* TITLE */
        .card-login h3 {
            font-weight: 800;
            margin-bottom: 30px;
        }

        /* INPUT */
        .input-group {
            position: relative;
            margin-bottom: 22px;
        }

        .input-group input {
            width: 100%;
            padding: 16px 50px;
            border-radius: 14px;
            border: 1px solid rgba(255, 255, 255, 0.1);
            background: rgba(255, 255, 255, 0.04);
            color: white;
            transition: .3s;
        }

        .input-group input:focus {
            border: 1px solid #22d3ee;
            background: rgba(255, 255, 255, 0.08);
            box-shadow: 0 0 20px rgba(34, 211, 238, 0.25);
            outline: none;
        }

        /* LABEL */
        .input-group label {
            position: absolute;
            top: 50%;
            left: 50px;
            transform: translateY(-50%);
            font-size: 13px;
            color: rgba(255, 255, 255, 0.5);
            transition: .25s;
        }

        .input-group input:focus + label,
        .input-group input:not(:placeholder-shown) + label {
            top: 6px;
            font-size: 11px;
            color: #22d3ee;
        }

        /* ICON */
        .input-group i {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            opacity: .5;
            transition: .3s;
        }

        .bi-person, .bi-lock {
            left: 15px;
        }
        .toggle-pass {
            right: 15px;
            cursor: pointer;
        }

        .input-group input:focus ~ i {
            opacity: 1;
            color: #22d3ee;
        }

        /* ERROR */
        input.error {
            border: 1px solid #ef4444;
        }

        /* BUTTON */
        .btn-login {
            width: 100%;
            padding: 14px;
            border: none;
            border-radius: 14px;
            background: linear-gradient(135deg, #6366f1, #22d3ee);
            font-weight: 600;
            letter-spacing: .5px;
            position: relative;
            overflow: hidden;
            transition: .3s;
        }

        /* SHINE EFFECT */
        .btn-login::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 50%;
            height: 100%;
            background: linear-gradient(120deg, transparent, rgba(255, 255, 255, 0.6), transparent);
            transition: .6s;
        }

        .btn-login:hover::before {
            left: 120%;
        }

        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow:
                0 10px 30px rgba(34, 211, 238, 0.4),
                0 0 20px rgba(99, 102, 241, 0.3);
        }

        /* LOADING */
        .btn-login.loading {
            pointer-events: none;
            opacity: .7;
        }

        .btn-login.loading::after {
            content: '';
            width: 18px;
            height: 18px;
            border: 3px solid white;
            border-top: 3px solid transparent;
            border-radius: 50%;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            animation: spin .8s linear infinite;
        }

        /* LINK */
        a {
            color: #22d3ee;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }

        p {
            color: rgba(255, 255, 255, 0.7);
        }

        /* TOAST */
        .toast-box {
            position: fixed;
            top: 20px;
            right: 20px;
            background: rgba(15, 23, 42, 0.9);
            padding: 14px 18px;
            border-radius: 12px;
            border-left: 4px solid #22d3ee;
            display: none;
            color: white;
        }

        /* ANIMATION */
        @keyframes spin {
            100% {
                transform: rotate(360deg);
            }
        }
        @keyframes fadeUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @media(max-width: 768px) {
            .left {
                display: none;
            }
        }
    </style>
</head>

<body>
    <div class="left">
        <h1>Kabar Nusantara</h1>
    </div>

    <div class="right">
        <div class="card-login">
            <h3 class="text-center">Masuk Akun</h3>

            <form method="POST" onsubmit="return handleSubmit()">
                <div class="input-group">
                    <i class="bi bi-person"></i>
                    <input type="text" id="username" name="username" placeholder=" ">
                    <label>Username</label>
                </div>

                <div class="input-group">
                    <i class="bi bi-lock"></i>
                    <input type="password" id="password" name="password" placeholder=" ">
                    <label>Password</label>
                    <i class="bi bi-eye toggle-pass" onclick="togglePassword()"></i>
                </div>

                <button id="btn" name="login" class="btn-login text-white">
                    <i class="bi bi-box-arrow-in-right me-2"></i> Masuk
                </button>
            </form>

            <p class="mt-3 text-center">
                Belum punya akun? <a href="register.php">Daftar</a>
            </p>
        </div>
    </div>

    <div class="toast-box" id="toast"></div>

    <script>
        function togglePassword() {
            const pass = document.getElementById("password");
            pass.type = pass.type === "password" ? "text" : "password";
        }

        function handleSubmit() {
            let valid = validateForm();
            if (valid) {
                document.getElementById("btn").classList.add("loading");
            }
            return valid;
        }

        function validateForm() {
            let user = document.getElementById("username");
            let pass = document.getElementById("password");

            let valid = true;

            user.classList.remove("error");
            pass.classList.remove("error");

            if (user.value.trim() === "") {
                user.classList.add("error");
                showToast("Username wajib diisi");
                valid = false;
            }

            if (pass.value.trim() === "") {
                pass.classList.add("error");
                showToast("Password wajib diisi");
                valid = false;
            }

            return valid;
        }

        function showToast(msg) {
            const toast = document.getElementById("toast");
            toast.innerText = msg;
            toast.style.display = "block";

            setTimeout(() => {
                toast.style.display = "none";
            }, 3000);
        }

        <?php if (isset($error)): ?>
            showToast("<?= $error ?>");
        <?php endif; ?>
    </script>
</body>
</html>