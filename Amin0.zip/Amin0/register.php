<?php
session_start();
include "includes/config.php";

if (isset($_POST['register'])) {
    $user = $_POST['username'];
    $pass = md5($_POST['password']);

    $cek = mysqli_query($conn, "SELECT * FROM users WHERE username='$user'");
    
    if (mysqli_num_rows($cek) > 0) {
        $error = "Username sudah digunakan!";
    } else {
        mysqli_query($conn, "INSERT INTO users (username, password, role) 
        VALUES ('$user','$pass','user')");

        // 🔥 LANGSUNG REDIRECT TANPA JEDA
        header("Location: login.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Register</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

<style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: 'Inter', 'Segoe UI', sans-serif;
    }

    body {
        height: 100vh;
        display: flex;
        background: radial-gradient(circle at top, #0f172a, #020617);
        overflow: hidden;
    }

    /* BACKGROUND LOGIN STYLE */
    body::before, body::after {
        content: '';
        position: absolute;
        border-radius: 50%;
        filter: blur(120px);
    }

    body::before {
        width: 600px;
        height: 600px;
        background: #4f46e5;
        top: -150px;
        left: -150px;
        opacity: .25;
    }

    body::after {
        width: 500px;
        height: 500px;
        background: #22d3ee;
        bottom: -150px;
        right: -150px;
        opacity: .2;
    }

    /* LEFT */
    .left {
        flex: 1;
        display: flex;
        justify-content: center;
        align-items: center;
        color: white;
    }

    .left h2 {
        font-size: 50px;
        font-weight: 900;
        background: linear-gradient(to right, #22d3ee, #4f46e5);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
    }

    /* RIGHT */
    .right {
        flex: 1;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    /* CARD */
    .card-box {
        width: 100%;
        max-width: 420px;
        padding: 45px;
        border-radius: 24px;
        background: rgba(255, 255, 255, 0.05);
        backdrop-filter: blur(35px);
        border: 1px solid rgba(255, 255, 255, 0.1);
        box-shadow: 0 25px 80px rgba(0, 0, 0, 0.8);
        color: white;
        animation: fadeUp .8s ease;
    }

    /* TITLE */
    .card-box h3 {
        font-weight: 800;
        margin-bottom: 30px;
    }

    /* FLOATING INPUT */
    .input-group {
        position: relative;
        margin-bottom: 20px;
    }

    .input-group input {
        width: 100%;
        padding: 16px 45px;
        border-radius: 12px;
        border: none;
        background: rgba(255, 255, 255, 0.06);
        color: white;
        transition: .3s;
    }

    .input-group label {
        position: absolute;
        top: 50%;
        left: 45px;
        transform: translateY(-50%);
        color: rgba(255, 255, 255, 0.5);
        pointer-events: none;
        transition: .25s;
        font-size: 14px;
    }

    .input-group input:focus + label,
    .input-group input:not(:placeholder-shown) + label {
        top: 5px;
        font-size: 11px;
        color: #22d3ee;
    }

    .input-group input:focus {
        background: rgba(255, 255, 255, 0.1);
        box-shadow: 0 0 0 1px #22d3ee, 0 0 12px rgba(34, 211, 238, 0.3);
    }

    /* ICON */
    .input-group i {
        position: absolute;
        top: 50%;
        transform: translateY(-50%);
        opacity: .6;
    }

    .bi-person, .bi-lock {
        left: 15px;
    }

    .toggle-pass {
        right: 15px;
        cursor: pointer;
    }

    /* ERROR */
    input.error {
        box-shadow: 0 0 0 1px #ef4444;
    }

    /* PASSWORD STRENGTH */
    .strength {
        height: 5px;
        border-radius: 10px;
        margin-top: 6px;
        background: #1e293b;
        overflow: hidden;
    }

    .strength span {
        display: block;
        height: 100%;
        width: 0%;
        transition: .3s;
    }

    /* BUTTON */
    .btn-register {
        width: 100%;
        padding: 13px;
        border: none;
        border-radius: 12px;
        background: linear-gradient(135deg, #4f46e5, #22d3ee);
        font-weight: 600;
        transition: .3s;
        position: relative;
    }

    .btn-register:hover {
        transform: translateY(-2px);
        box-shadow: 0 10px 30px rgba(79, 70, 229, 0.4);
    }

    .btn-register.loading {
        pointer-events: none;
        opacity: .7;
    }

    /* LINK */
    a {
        color: white;
        text-decoration: none;
    }

    a:hover {
        text-decoration: underline;
    }

    /* TOAST */
    .toast-box {
        position: fixed;
        top: 20px;
        right: 20px;
        background: #020617;
        padding: 14px 18px;
        border-radius: 12px;
        border-left: 4px solid #22d3ee;
        display: none;
        color: white;
    }

    /* ANIMATION */
    @keyframes fadeUp {
        from {
            opacity: 0;
            transform: translateY(30px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    @media(max-width: 768px) {
        .left {
            display: none;
        }
    }
</style>
</head>

<body>

<div class="left">
    <h2>Kabar Nusantara</h2>
</div>

<div class="right">

<div class="card-box">

<h3 class="text-center">Buat Akun</h3>

<form method="POST" onsubmit="return handleSubmit()">

<div class="input-group">
    <i class="bi bi-person"></i>
    <input type="text" id="username" name="username" placeholder=" ">
    <label>Username</label>
</div>

<div class="input-group">
    <i class="bi bi-lock"></i>
    <input type="password" id="password" name="password" placeholder=" " oninput="checkStrength()">
    <label>Password</label>
    <i class="bi bi-eye toggle-pass" onclick="togglePass('password')"></i>

    <div class="strength"><span id="bar"></span></div>
</div>

<button id="btn" name="register" class="btn-register text-white">
    Daftar Sekarang
</button>

</form>

<p class="mt-3 text-center">
Sudah punya akun? <a href="login.php">Login</a>
</p>

</div>
</div>

<div id="toast" class="toast-box"></div>

    <script>
        function togglePass(id) {
            const input = document.getElementById(id);
            input.type = input.type === "password" ? "text" : "password";
        }

        function checkStrength() {
            let val = document.getElementById("password").value;
            let bar = document.getElementById("bar");

            let strength = 0;
            if (val.length > 3) strength++;
            if (val.match(/[A-Z]/)) strength++;
            if (val.match(/[0-9]/)) strength++;

            bar.style.width = (strength * 33) + "%";

            if (strength == 1) bar.style.background = "#ef4444";
            if (strength == 2) bar.style.background = "#facc15";
            if (strength == 3) bar.style.background = "#22d3ee";
        }

        function handleSubmit() {
            let valid = validateForm();
            if (valid) {
                document.getElementById("btn").classList.add("loading");
            }
            return valid;
        }

        function validateForm() {
            let user = document.getElementById("username");
            let pass = document.getElementById("password");

            let valid = true;

            user.classList.remove("error");
            pass.classList.remove("error");

            if (user.value.trim() === "") {
                showToast("Username wajib diisi");
                user.classList.add("error");
                valid = false;
            }

            if (pass.value.length < 4) {
                showToast("Password minimal 4 karakter");
                pass.classList.add("error");
                valid = false;
            }

            return valid;
        }

        function showToast(msg) {
            const toast = document.getElementById("toast");
            toast.innerText = msg;
            toast.style.display = "block";

            setTimeout(() => {
                toast.style.display = "none";
            }, 3000);
        }

        <?php if (isset($error)): ?>
            showToast("<?= $error ?>");
        <?php endif; ?>
    </script>

</body>
</html>